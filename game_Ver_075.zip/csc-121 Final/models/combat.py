# models/combat.py
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Any, List
import random
import logging
from config import FLEE_BASE_CHANCE, CRITICAL_HIT_CHANCE, CRITICAL_HIT_MULTIPLIER
from database import Database

@dataclass
class CombatAction:
    type: str  # 'attack', 'use_item', 'flee'
    target: Optional[str] = None
    item: Optional[Dict] = None

class CombatSystem:
    def __init__(self):
        self.status_effects: Dict[str, Dict] = {}

    def process_turn(self, attacker: Any, defender: Any, action: CombatAction) -> Dict[str, Any]:
        result = {
            'success': True,
            'damage_dealt': 0,
            'item_used': None,
            'fled': False,
            'messages': [],
            'roll_info': {}  # For roll information
        }

        if action.type == 'attack':
            hit_chance = self._calculate_hit_chance(attacker, defender)
            hit_roll = random.random()
            result['roll_info']['hit_roll'] = hit_roll
            result['roll_info']['hit_chance'] = hit_chance
            
            if hit_roll < hit_chance:
                damage, is_crit, crit_roll = self._calculate_damage(attacker, defender)
                result['roll_info']['damage_base'] = damage / (CRITICAL_HIT_MULTIPLIER if is_crit else 1)
                result['roll_info']['crit_roll'] = crit_roll
                result['roll_info']['is_crit'] = is_crit
                
                defender.take_damage(damage)
                result['damage_dealt'] = damage
                
                # Detailed combat message
                crit_text = " **CRITICAL HIT FOR DOUBLE DAMAGE!**" if is_crit else ""
                roll_text = f"[Hit Roll: {hit_roll:.2f} vs {hit_chance:.2f}]"
                crit_roll_text = f"[Crit Roll: {crit_roll:.2f}]" if is_crit else ""
                
                message = (f"{attacker.name} attacks {defender.name}{crit_text}! "
                          f"{roll_text} {crit_roll_text} "
                          f"Dealing {damage} damage!")
                
                result['messages'].append(message)
                
                # Log the detailed combat information
                logging.info(f"Combat Roll - {attacker.name} vs {defender.name}:")
                logging.info(f"  Hit Chance: {hit_chance:.2f}")
                logging.info(f"  Hit Roll: {hit_roll:.2f}")
                logging.info(f"  Base Damage: {result['roll_info']['damage_base']}")
                if is_crit:
                    logging.info(f"  Critical Roll: {crit_roll:.2f}")
                    logging.info(f"  Critical Hit! Damage multiplied by {CRITICAL_HIT_MULTIPLIER}")
                logging.info(f"  Final Damage: {damage}")
            else:
                result['success'] = False
                message = f"{attacker.name}'s attack missed! {hit_roll:.2f} > {hit_chance:.2f}"
                result['messages'].append(message)
                logging.info(f"Combat Miss - {attacker.name} vs {defender.name}:")
                logging.info(f"  Hit Chance: {hit_chance:.2f}")
                logging.info(f"  Hit Roll: {hit_roll:.2f}")

        elif action.type == 'use_item':
            if action.item in attacker.inventory:
                self._apply_item_effect(attacker, action.item)
                attacker.inventory.remove(action.item)
                result['item_used'] = action.item
                result['messages'].append(f"{attacker.name} used {action.item['name']}")

        elif action.type == 'flee':
            flee_roll = random.random()
            result['roll_info']['flee_roll'] = flee_roll
            result['roll_info']['flee_chance'] = FLEE_BASE_CHANCE
            
            if flee_roll < FLEE_BASE_CHANCE:
                result['fled'] = True
                message = f"{attacker.name} successfully fled! [{flee_roll:.2f} < {FLEE_BASE_CHANCE}]"
                result['messages'].append(message)
                logging.info(f"Flee Success - {attacker.name}:")
                logging.info(f"  Flee Chance: {FLEE_BASE_CHANCE}")
                logging.info(f"  Flee Roll: {flee_roll:.2f}")
            else:
                result['success'] = False
                message = f"{attacker.name} failed to flee! [{flee_roll:.2f} > {FLEE_BASE_CHANCE}]"
                result['messages'].append(message)
                logging.info(f"Flee Failure - {attacker.name}:")
                logging.info(f"  Flee Chance: {FLEE_BASE_CHANCE}")
                logging.info(f"  Flee Roll: {flee_roll:.2f}")

        return result

    def _calculate_hit_chance(self, attacker: Any, defender: Any) -> float:
        base_chance = 0.8  # 80% base hit chance
        attack = attacker.calculate_total_attack() if hasattr(attacker, 'calculate_total_attack') else attacker.attack
        defense = defender.calculate_total_defense() if hasattr(defender, 'calculate_total_defense') else defender.defense
        
        attack_defense_diff = attack - defense
        
        # Each point of difference adjusts hit chance by 5%
        modifier = attack_defense_diff * 0.05
        final_chance = min(max(base_chance + modifier, 0.1), 0.95)  # Cap between 10% and 95%
        
        logging.info(f"Hit Chance Calculation - {attacker.name} vs {defender.name}:")
        logging.info(f"  Base Chance: {base_chance}")
        logging.info(f"  Attack: {attack}")
        logging.info(f"  Defense: {defense}")
        logging.info(f"  Modifier: {modifier}")
        logging.info(f"  Final Chance: {final_chance}")
        
        return final_chance

    def _calculate_damage(self, attacker: Any, defender: Any) -> Tuple[int, bool, float]:
        base_damage = attacker.calculate_total_attack() if hasattr(attacker, 'calculate_total_attack') else attacker.attack
        defense = defender.calculate_total_defense() if hasattr(defender, 'calculate_total_defense') else defender.defense

        damage = max(1, base_damage - defense)
        crit_roll = random.random()
        is_crit = crit_roll < CRITICAL_HIT_CHANCE

        if is_crit:
            damage = int(damage * CRITICAL_HIT_MULTIPLIER)

        return damage, is_crit, crit_roll

    def _apply_item_effect(self, character: Any, item: Dict[str, Any]) -> None:
        if 'type' not in item:
            logging.error(f"Item missing 'type' field: {item}")
            return
            
        if item['type'] == 'consumable':
            if 'effect' not in item:
                logging.error(f"Consumable item missing 'effect' field: {item}")
                return
            try:
                heal_amount = int(item['effect'].split('_')[1])
                character.heal(heal_amount)
                logging.info(f"Applied healing effect: {heal_amount}")
            except (IndexError, ValueError) as e:
                logging.error(f"Invalid healing effect format: {item['effect']} - {str(e)}")
        elif item['type'] == 'buff':
            self.status_effects[character.name] = {
                'effect': item['effect'],
                'duration': item.get('duration', 1)
            }

    def check_combat_status(self, character: Any, enemy: Any) -> Tuple[bool, str]:
        """Check if combat has ended and determine the outcome."""
        if character.current_health <= 0:
            return True, 'defeat'
        if enemy.current_health <= 0:
            return True, 'victory'
        return False, ''

    def distribute_rewards(self, character: Any, enemy: Any) -> Dict[str, Any]:
        """Calculate and distribute rewards from defeating an enemy."""
        db = Database()
        rewards = {
            'xp': enemy.xp_value,
            'items': [],
            'copper': 0
        }

        # Get drops from enemy
        drops = enemy.get_drops()
        for drop_type, value in drops:
            if drop_type == 'copper':
                rewards['copper'] = value
                character.money += value
            elif drop_type == 'item':
                # Get complete item data from database
                item_data = db.get_item(value)
                if item_data:
                    rewards['items'].append(item_data['name'])
                    character.add_item(item_data)
                else:
                    logging.error(f"Failed to load item data for drop: {value}")

        # Add XP
        character.add_xp(rewards['xp'])
        logging.info(f"Combat rewards distributed: {rewards}")
        return rewards