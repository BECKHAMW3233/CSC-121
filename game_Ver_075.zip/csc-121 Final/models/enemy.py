# models/enemy.py
from dataclasses import dataclass
from typing import Optional, Dict, List, Any
from database import Database
import random
import logging

@dataclass
class Enemy:
    name: str
    tier: int
    current_health: Optional[int] = None
    attack: int = 0
    defense: int = 0
    health: int = 0
    xp_value: int = 0
    min_copper: int = 0
    max_copper: int = 0
    common_drops: List[str] = None
    rare_drops: List[str] = None

    def __post_init__(self):
        self._load_stats()
        if self.current_health is None:
            self.current_health = self.health
        if self.common_drops is None:
            self.common_drops = []
        if self.rare_drops is None:
            self.rare_drops = []

    def _load_stats(self) -> None:
        db = Database()
        enemy_data = db.get_enemy(self.name)
        if not enemy_data:
            logging.error(f"Failed to load enemy data for {self.name}")
            raise ValueError(f"Invalid enemy: {self.name}")

        self.attack = enemy_data['attack']
        self.defense = enemy_data['defense']
        self.health = enemy_data['health']
        self.xp_value = enemy_data['xp_value']
        self.min_copper = enemy_data['min_copper']
        self.max_copper = enemy_data['max_copper']
        self.common_drops = enemy_data['common_drops'].split(',') if enemy_data['common_drops'] else []
        self.rare_drops = enemy_data['rare_drops'].split(',') if enemy_data['rare_drops'] else []

    def take_damage(self, damage: int) -> bool:
        self.current_health = max(0, self.current_health - damage)
        logging.info(f"{self.name} took {damage} damage. Health: {self.current_health}/{self.health}")
        return self.current_health > 0

    def is_defeated(self) -> bool:
        return self.current_health <= 0

    def get_drops(self) -> List[tuple[str, Any]]:
        drops = []
        
        # Money drops
        copper = random.randint(self.min_copper, self.max_copper)
        drops.append(('copper', copper))
        
        # Common drops
        if self.common_drops and random.random() < 0.6:
            drops.append(('item', random.choice(self.common_drops)))
            
        # Rare drops
        if self.rare_drops and random.random() < 0.1:
            drops.append(('item', random.choice(self.rare_drops)))
            
        logging.info(f"{self.name} dropped: {drops}")
        return drops

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'tier': self.tier,
            'current_health': self.current_health,
            'attack': self.attack,
            'defense': self.defense,
            'health': self.health,
            'xp_value': self.xp_value,
            'min_copper': self.min_copper,
            'max_copper': self.max_copper,
            'common_drops': self.common_drops,
            'rare_drops': self.rare_drops
        }