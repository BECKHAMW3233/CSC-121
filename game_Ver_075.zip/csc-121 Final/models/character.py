# models/character.py
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import logging
from database import Database

@dataclass
class Character:
    name: str
    age: int
    tier: int = 1
    xp: int = 0
    current_health: Optional[int] = None
    inventory: List[Dict] = field(default_factory=list)
    equipped_weapon: Optional[Dict] = None
    equipped_armor: Optional[Dict] = None
    equipped_shield: Optional[Dict] = None
    money: int = 0
    
    def __post_init__(self):
        """Initialize character stats after creation"""
        self.load_stats()
        if self.current_health is None:
            self.current_health = self.max_health

    def load_stats(self) -> None:
        """Load base stats and initial equipment for character tier"""
        db = Database()
        tier_data = db.get_tier_data(self.tier)
        if not tier_data:
            logging.error(f"Failed to load tier {self.tier} data for character {self.name}")
            raise ValueError(f"Invalid tier: {self.tier}")

        # Load base stats
        self.title = tier_data['title']
        self.attack = tier_data['attack']
        self.defense = tier_data['defense']
        self.max_health = tier_data['health']
        self.special_ability = tier_data['special_ability']

        # Load initial equipment if character is new
        if not self.equipped_weapon and 'weapon' in tier_data and tier_data['weapon']:
            initial_weapon = db.get_item(tier_data['weapon'])
            if initial_weapon:
                logging.info(f"Loading initial weapon for {self.name}: {initial_weapon['name']}")
                self.equipped_weapon = initial_weapon
            else:
                logging.error(f"Failed to load initial weapon {tier_data['weapon']} for {self.name}")
        
        if not self.equipped_armor and 'armor' in tier_data and tier_data['armor']:
            initial_armor = db.get_item(tier_data['armor'])
            if initial_armor:
                logging.info(f"Loading initial armor for {self.name}: {initial_armor['name']}")
                self.equipped_armor = initial_armor
            else:
                logging.error(f"Failed to load initial armor {tier_data['armor']} for {self.name}")

    def add_xp(self, xp_amount: int) -> None:
        self.xp += xp_amount
        logging.info(f"{self.name} gained {xp_amount} XP. Total: {self.xp}")
        self.check_level_up()

    def check_level_up(self) -> None:
        db = Database()
        next_tier = self.tier + 1
        next_tier_data = db.get_tier_data(next_tier)
        
        if next_tier_data and self.xp >= next_tier_data['min_xp']:
            self.level_up()

    def level_up(self) -> None:
        self.tier += 1
        old_health = self.max_health
        self.load_stats()
        # Heal proportionally when leveling up
        health_percent = self.current_health / old_health
        self.current_health = int(self.max_health * health_percent)
        logging.info(f"{self.name} leveled up to tier {self.tier} ({self.title})")

    def take_damage(self, damage: int) -> bool:
        self.current_health = max(0, self.current_health - damage)
        logging.info(f"{self.name} took {damage} damage. Health: {self.current_health}/{self.max_health}")
        return self.current_health > 0

    def heal(self, amount: int) -> int:
        old_health = self.current_health
        self.current_health = min(self.max_health, self.current_health + amount)
        actual_heal = self.current_health - old_health
        logging.info(f"{self.name} healed for {actual_heal}. Health: {self.current_health}/{self.max_health}")
        return actual_heal

    def use_healing_potion(self, potion: Dict) -> bool:
        if potion['type'] != 'consumable':
            logging.warning(f"Attempted to use non-consumable item as potion: {potion['name']}")
            return False
            
        try:
            heal_amount = int(potion['effect'].split('_')[1])
            self.heal(heal_amount)
            self.remove_item(potion)
            logging.info(f"{self.name} used {potion['name']} and healed for {heal_amount}")
            return True
        except (IndexError, ValueError) as e:
            logging.error(f"Invalid potion effect format: {potion['effect']} - {str(e)}")
            return False

    def add_item(self, item: Dict) -> None:
        """Add an item to the character's inventory, ensuring complete item data"""
        if isinstance(item, str):
            # If just a name was passed, get complete item data
            db = Database()
            item_data = db.get_item(item)
            if item_data:
                self.inventory.append(item_data)
                logging.info(f"{self.name} acquired {item_data['name']}")
            else:
                logging.error(f"Failed to load item data for: {item}")
        else:
            # If complete item data was passed, add it directly
            self.inventory.append(item)
            logging.info(f"{self.name} acquired {item['name']}")

    def remove_item(self, item: Dict) -> bool:
        try:
            self.inventory.remove(item)
            logging.info(f"{self.name} removed {item['name']} from inventory")
            return True
        except ValueError:
            logging.warning(f"Failed to remove {item['name']} from {self.name}'s inventory - item not found")
            return False

    def equip_item(self, item: Dict) -> bool:
        if item['type'] == 'weapon':
            if self.equipped_weapon:
                self.inventory.append(self.equipped_weapon)
            self.equipped_weapon = item
            logging.info(f"{self.name} equipped weapon: {item['name']}")
        elif item['type'] == 'armor':
            if self.equipped_armor:
                self.inventory.append(self.equipped_armor)
            self.equipped_armor = item
            logging.info(f"{self.name} equipped armor: {item['name']}")
        elif item['type'] == 'shield':
            if self.equipped_shield:
                self.inventory.append(self.equipped_shield)
            self.equipped_shield = item
            logging.info(f"{self.name} equipped shield: {item['name']}")
        else:
            return False
        
        self.inventory.remove(item)
        return True

    def calculate_total_attack(self) -> int:
        total = self.attack
        if self.equipped_weapon:
            min_dmg = float(self.equipped_weapon.get('base_damage_min', 0))
            max_dmg = float(self.equipped_weapon.get('base_damage_max', 0))
            total += (min_dmg + max_dmg) / 2
        return int(total)

    def calculate_total_defense(self) -> int:
        total = self.defense
        if self.equipped_armor:
            total += float(self.equipped_armor.get('base_defense', 0))
        if self.equipped_shield:
            total += float(self.equipped_shield.get('base_defense', 0))
        return int(total)

    def to_dict(self) -> Dict:
        return {
            'name': self.name,
            'age': self.age,
            'tier': self.tier,
            'xp': self.xp,
            'current_health': self.current_health,
            'inventory': self.inventory,
            'equipped_weapon': self.equipped_weapon,
            'equipped_armor': self.equipped_armor,
            'equipped_shield': self.equipped_shield,
            'money': self.money
        }

    def get_status_effects(self) -> List[str]:
        """Get a list of active status effects on the character."""
        effects = []
        if getattr(self, 'special_ability', 'none') != 'none':
            effects.append(self.special_ability)
        return effects