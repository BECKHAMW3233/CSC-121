# models/dungeon.py
import random
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Any
import logging
from database import Database
from models.enemy import Enemy
from config import ENEMY_SPAWN_CHANCE

@dataclass
class Room:
    enemies: List[Enemy] = field(default_factory=list)
    items: List[Dict] = field(default_factory=list)
    is_cleared: bool = False
    is_visible: bool = False
    doors: Dict[str, bool] = field(default_factory=lambda: {
        'north': False, 'south': False, 'east': False, 'west': False
    })

    def has_enemy(self) -> bool:
        return len(self.enemies) > 0

    def get_enemy(self) -> Enemy:
        return self.enemies[0] if self.enemies else None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'enemies': [enemy.to_dict() for enemy in self.enemies],
            'items': self.items,
            'is_cleared': self.is_cleared,
            'is_visible': self.is_visible,
            'doors': self.doors
        }

class Dungeon:
    def __init__(self, tier: int, size: int = 10):
        self.tier = tier
        self.size = size
        self.rooms = [[Room() for _ in range(size)] for _ in range(size)]
        self.player_pos = (0, 0)
        self.generate_dungeon()
        logging.info(f"Generated tier {tier} dungeon of size {size}x{size}")

    def generate_dungeon(self):
        self._generate_maze()
        self._populate_rooms()
        self.rooms[0][0].is_visible = True
        self._update_visibility()

    def _generate_maze(self):
        def carve_path(x: int, y: int, visited: set):
            visited.add((x, y))
            directions = [(0, 1, 'south', 'north'), (0, -1, 'north', 'south'),
                         (1, 0, 'east', 'west'), (-1, 0, 'west', 'east')]
            random.shuffle(directions)
            
            for dx, dy, dir1, dir2 in directions:
                new_x, new_y = x + dx, y + dy
                if (0 <= new_x < self.size and 0 <= new_y < self.size and 
                    (new_x, new_y) not in visited):
                    self.rooms[y][x].doors[dir1] = True
                    self.rooms[new_y][new_x].doors[dir2] = True
                    carve_path(new_x, new_y, visited)

        carve_path(0, 0, set())

    def _populate_rooms(self):
        db = Database()
        enemies_df = db.load_data('enemies')
        tier_enemies = enemies_df[enemies_df['tier'] <= self.tier]
        
        if tier_enemies.empty:
            logging.error(f"No enemies found for tier {self.tier}")
            return

        for y in range(self.size):
            for x in range(self.size):
                if random.random() < ENEMY_SPAWN_CHANCE and (x, y) != (0, 0):
                    enemy_data = tier_enemies.sample().iloc[0]
                    enemy = Enemy(
                        name=enemy_data['name'],
                        tier=enemy_data['tier']
                    )
                    self.rooms[y][x].enemies.append(enemy)

    def move_player(self, direction: str) -> bool:
        current_room = self.get_current_room()
        if not current_room.doors[direction]:
            return False

        dx, dy = {
            'north': (0, -1),
            'south': (0, 1),
            'east': (1, 0),
            'west': (-1, 0)
        }[direction]

        new_x = self.player_pos[0] + dx
        new_y = self.player_pos[1] + dy

        if 0 <= new_x < self.size and 0 <= new_y < self.size:
            self.player_pos = (new_x, new_y)
            self._update_visibility()
            logging.info(f"Player moved to position {self.player_pos}")
            return True
        return False

    def move_player_random_adjacent(self) -> bool:
        current_room = self.get_current_room()
        available_directions = [dir for dir, has_door in current_room.doors.items() if has_door]
        
        if not available_directions:
            return False
            
        direction = random.choice(available_directions)
        return self.move_player(direction)

    def _update_visibility(self):
        x, y = self.player_pos
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                new_x, new_y = x + dx, y + dy
                if 0 <= new_x < self.size and 0 <= new_y < self.size:
                    self.rooms[new_y][new_x].is_visible = True

    def get_current_room(self) -> Room:
        return self.rooms[self.player_pos[1]][self.player_pos[0]]

    def to_dict(self) -> Dict[str, Any]:
        return {
            'tier': self.tier,
            'size': self.size,
            'player_pos': self.player_pos,
            'rooms': [[room.to_dict() for room in row] for row in self.rooms]
        }