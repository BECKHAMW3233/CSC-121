# gui/main_window.py
import tkinter as tk
from tkinter import ttk
from typing import Any, Callable, Dict, Optional
from config import WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE
import logging

class GameWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(WINDOW_TITLE)
        self.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.configure(bg='black')
        self.current_frame: Optional[GameFrame] = None
        self.player = None
        self.setup_styles()

    def setup_styles(self):
        style = ttk.Style()
        style.configure('Game.TFrame', background='black')
        style.configure('Game.TLabel', background='black', foreground='white')
        style.configure('Game.TButton', padding=5)

    def clear_menu(self):
        if self.current_frame:
            self.current_frame.destroy()

    def setup_game_ui(self):
        self.clear_menu()
        self.current_frame = GameFrame(self)
        self.current_frame.pack(expand=True, fill='both')
        
        save_button = ttk.Button(self.current_frame, text="Save Game", 
                                command=lambda: self.event_generate("<<SaveGame>>"))
        save_button.pack(side='top', pady=5)

    def bind_keys(self):
        if not self.current_frame:
            return
        self.bind('<w>', lambda e: self.current_frame.handle_movement('north'))
        self.bind('<s>', lambda e: self.current_frame.handle_movement('south'))
        self.bind('<a>', lambda e: self.current_frame.handle_movement('west'))
        self.bind('<d>', lambda e: self.current_frame.handle_movement('east'))
        self.bind('<i>', lambda e: self.current_frame.toggle_inventory())
        self.bind('<Escape>', lambda e: self.current_frame.show_pause_menu())

    def update_game_view(self, dungeon: Any, player: Any):
        self.player = player
        if isinstance(self.current_frame, GameFrame):
            self.current_frame.update_game_view(dungeon, player)

    def update_stats_view(self, player: Any):
        self.player = player
        if isinstance(self.current_frame, GameFrame):
            self.current_frame.update_stats_view(player)

    def show_inventory_ui(self, player: Any):
        if isinstance(self.current_frame, GameFrame):
            self.current_frame.show_inventory_ui(player)

class GameFrame(ttk.Frame):
    def __init__(self, master: tk.Tk):
        super().__init__(master, style='Game.TFrame')
        self.setup_ui()
        self.bind_events()

    def setup_ui(self):
        self.game_view = ttk.Frame(self, style='Game.TFrame')
        self.game_view.pack(side='left', expand=True, fill='both')

        self.sidebar = ttk.Frame(self, style='Game.TFrame', width=200)
        self.sidebar.pack(side='right', fill='y')
        self.sidebar.pack_propagate(False)

        self.setup_stats_view()
        self.setup_inventory_view()

    def setup_stats_view(self):
        self.stats_frame = ttk.LabelFrame(self.sidebar, text="Character Stats", style='Game.TFrame')
        self.stats_frame.pack(fill='x', padx=5, pady=5)
        
        self.stats_labels = {}
        for stat in ['Name', 'Title', 'Level', 'Health', 'Attack', 'Defense', 'XP', 'Money']:
            self.stats_labels[stat] = ttk.Label(self.stats_frame, style='Game.TLabel')
            self.stats_labels[stat].pack(anchor='w', padx=5)

    def setup_inventory_view(self):
        self.inventory_frame = ttk.LabelFrame(self.sidebar, text="Inventory", style='Game.TFrame')
        self.inventory_frame.pack(fill='x', padx=5, pady=5)
        
        self.inventory_list = tk.Listbox(
            self.inventory_frame,
            bg='black',
            fg='white',
            selectmode=tk.SINGLE
        )
        self.inventory_list.pack(fill='both', expand=True)

    def bind_events(self):
        self.inventory_list.bind('<Double-Button-1>', self.handle_inventory_click)
        self.inventory_list.bind('<Button-3>', self.handle_inventory_click)

    def update_game_view(self, dungeon: Any, player: Any):
        for widget in self.game_view.winfo_children():
            widget.destroy()

        canvas = tk.Canvas(
            self.game_view,
            bg='black',
            width=600,
            height=600
        )
        canvas.pack(expand=True)

        room_size = 50
        player_x, player_y = dungeon.player_pos
        offset_x = 300 - player_x * room_size
        offset_y = 300 - player_y * room_size

        for y in range(max(0, player_y-4), min(dungeon.size, player_y+5)):
            for x in range(max(0, player_x-4), min(dungeon.size, player_x+5)):
                if dungeon.rooms[y][x].is_visible:
                    self.draw_room(canvas, x, y, dungeon.rooms[y][x], room_size, offset_x, offset_y)

        self.draw_player(canvas, player_x, player_y, room_size, offset_x, offset_y)

    def draw_room(self, canvas: tk.Canvas, x: int, y: int, room: Any, size: int, offset_x: int, offset_y: int):
        x1 = x * size + offset_x
        y1 = y * size + offset_y
        x2 = x1 + size
        y2 = y1 + size

        canvas.create_rectangle(x1, y1, x2, y2, fill='gray20', outline='white')

        if room.doors['north']:
            canvas.create_line(x1+size//3, y1, x2-size//3, y1, fill='white')
        if room.doors['south']:
            canvas.create_line(x1+size//3, y2, x2-size//3, y2, fill='white')
        if room.doors['east']:
            canvas.create_line(x2, y1+size//3, x2, y2-size//3, fill='white')
        if room.doors['west']:
            canvas.create_line(x1, y1+size//3, x1, y2-size//3, fill='white')

        center_x = x1 + size//2
        center_y = y1 + size//2
        
        if room.enemies:
            canvas.create_text(center_x, center_y-10, text='E', fill='red', font=('Arial', 12, 'bold'))
        if room.items:
            canvas.create_text(center_x, center_y+10, text='I', fill='yellow', font=('Arial', 12, 'bold'))
        if room.is_cleared:
            canvas.create_text(center_x+15, center_y-15, text='✓', fill='green', font=('Arial', 12, 'bold'))

    def draw_player(self, canvas: tk.Canvas, x: int, y: int, size: int, offset_x: int, offset_y: int):
        player_screen_x = x * size + offset_x + size//2
        player_screen_y = y * size + offset_y + size//2
        canvas.create_oval(
            player_screen_x-5, player_screen_y-5,
            player_screen_x+5, player_screen_y+5,
            fill='green', outline='white'
        )

    def update_stats_view(self, player: Any):
        self.stats_labels['Name'].config(text=f"Name: {player.name}")
        self.stats_labels['Title'].config(text=f"Title: {player.title}")
        self.stats_labels['Level'].config(text=f"Level: {player.tier}")
        self.stats_labels['Health'].config(text=f"Health: {player.current_health}/{player.max_health}")
        self.stats_labels['Attack'].config(text=f"Attack: {player.calculate_total_attack()}")
        self.stats_labels['Defense'].config(text=f"Defense: {player.calculate_total_defense()}")
        self.stats_labels['XP'].config(text=f"XP: {player.xp}")
        self.stats_labels['Money'].config(text=f"Money: {player.money} copper")

        self.inventory_list.delete(0, tk.END)
        for item in player.inventory:
            self.inventory_list.insert(tk.END, item['name'])

    def show_inventory_ui(self, player):
        inventory_window = tk.Toplevel(self)
        inventory_window.title("Inventory")
        inventory_window.geometry("400x600")
        inventory_window.transient(self)
        inventory_window.focus_set()

        # Equipment Section
        equipment_frame = ttk.LabelFrame(inventory_window, text="Equipment")
        equipment_frame.pack(fill='x', padx=5, pady=5)
        
        equipped_weapon = player.equipped_weapon['name'] if player.equipped_weapon else 'None'
        equipped_armor = player.equipped_armor['name'] if player.equipped_armor else 'None'
        equipped_shield = player.equipped_shield['name'] if player.equipped_shield else 'None'
        
        weapon_dmg = f" (DMG: {player.equipped_weapon['base_damage_min']}-{player.equipped_weapon['base_damage_max']})" if player.equipped_weapon else ""
        armor_def = f" (DEF: {player.equipped_armor['base_defense']})" if player.equipped_armor else ""
        shield_def = f" (DEF: {player.equipped_shield['base_defense']})" if player.equipped_shield else ""
        
        ttk.Label(equipment_frame, text=f"Weapon: {equipped_weapon}{weapon_dmg}").pack(anchor='w', padx=5)
        ttk.Label(equipment_frame, text=f"Armor: {equipped_armor}{armor_def}").pack(anchor='w', padx=5)
        ttk.Label(equipment_frame, text=f"Shield: {equipped_shield}{shield_def}").pack(anchor='w', padx=5)

        # Inventory Section with scrollbar
        items_frame = ttk.LabelFrame(inventory_window, text="Items")
        items_frame.pack(fill='both', expand=True, padx=5, pady=5)

        canvas = tk.Canvas(items_frame)
        scrollbar = ttk.Scrollbar(items_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        for item in player.inventory:
            item_frame = ttk.Frame(scrollable_frame)
            item_frame.pack(fill='x', padx=5, pady=2)
            
            item_info = f"{item['name']}"
            if item['type'] == 'weapon':
                item_info += f" (DMG: {item['base_damage_min']}-{item['base_damage_max']})"
            elif item['type'] in ['armor', 'shield']:
                item_info += f" (DEF: {item['base_defense']})"
            elif item['type'] == 'consumable':
                item_info += f" ({item['effect']})"
                
            ttk.Label(item_frame, text=item_info).pack(side='left')
            
            if item['type'] in ['weapon', 'armor', 'shield']:
                ttk.Button(
                    item_frame,
                    text="Equip",
                    command=lambda i=item: self._equip_item(player, i)
                ).pack(side='right')
            elif item['type'] == 'consumable':
                ttk.Button(
                    item_frame,
                    text="Use",
                    command=lambda i=item: self._use_item(player, i)
                ).pack(side='right')

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def _equip_item(self, player, item):
        if player.equip_item(item):
            self.update_stats_view(player)
            self.show_inventory_ui(player)

    def _use_item(self, player, item):
        used = False
        if item['type'] == 'consumable':
            used = player.use_healing_potion(item)
            if used:
                logging.info(f"Used {item['name']}")
                self.update_stats_view(player)
                self.show_inventory_ui(player)
        return used

    def handle_inventory_click(self, event):
        selection = self.inventory_list.curselection()
        if not selection:
            return
            
        index = selection[0]
        item_name = self.inventory_list.get(index)
        
        popup = tk.Menu(self, tearoff=0)
        
        # Find the selected item in player's inventory
        selected_item = None
        for item in self.master.player.inventory:
            if item['name'] == item_name:
                selected_item = item
                break
                
        if selected_item:
            if selected_item['type'] == 'consumable':
                popup.add_command(
                    label="Use",
                    command=lambda: self._use_item(self.master.player, selected_item)
                )
            elif selected_item['type'] in ['weapon', 'armor', 'shield']:
                popup.add_command(
                    label="Equip",
                    command=lambda: self._equip_item(self.master.player, selected_item)
                )
            
            # Show popup menu at click location
            try:
                popup.tk_popup(event.x_root, event.y_root)
            finally:
                popup.grab_release()

def _equip_item(self, player, item):
    """Handle equipping an item"""
    if player.equip_item(item):
        logging.info(f"Equipped {item['name']}")
        self.update_stats_view(player)
        self.show_inventory_ui(player)  # Refresh inventory display

def _use_item(self, player, item):
    """Handle using a consumable item"""
    used = False
    if item['type'] == 'consumable':
        used = player.use_healing_potion(item)
        if used:
            logging.info(f"Used {item['name']}")
            self.update_stats_view(player)
            self.show_inventory_ui(player)  # Refresh inventory display
    return used

def setup_inventory_view(self):
    """Set up the inventory view with proper bindings"""
    self.inventory_frame = ttk.LabelFrame(self.sidebar, text="Inventory", style='Game.TFrame')
    self.inventory_frame.pack(fill='x', padx=5, pady=5)
    
    self.inventory_list = tk.Listbox(
        self.inventory_frame,
        bg='black',
        fg='white',
        selectmode=tk.SINGLE
    )
    self.inventory_list.pack(fill='both', expand=True)
    
    # Bind both double-click and right-click
    self.inventory_list.bind('<Double-Button-1>', self.handle_inventory_click)
    self.inventory_list.bind('<Button-3>', self.handle_inventory_click)

    def handle_movement(self, direction: str):
        self.event_generate(f"<<Move{direction.capitalize()}>>")

    def toggle_inventory(self):
        self.event_generate("<<ToggleInventory>>")

    def show_pause_menu(self):
        pause_window = tk.Toplevel(self)
        pause_window.title("Pause Menu")
        pause_window.geometry("200x250")
        pause_window.transient(self)
        pause_window.focus_set()
        
        ttk.Button(pause_window, text="Resume", command=pause_window.destroy).pack(pady=5)
        ttk.Button(pause_window, text="Save Game", command=lambda: self.event_generate("<<SaveGame>>")).pack(pady=5)
        ttk.Button(pause_window, text="Load Game", command=lambda: self.event_generate("<<LoadGame>>")).pack(pady=5)
        ttk.Button(pause_window, text="Quit", command=lambda: self.event_generate("<<QuitGame>>")).pack(pady=5)