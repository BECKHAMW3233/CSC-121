# gui/combat_window.py
from tkinter import ttk
import tkinter as tk
from typing import Any, Callable, Dict
import logging
from models.combat import CombatAction

class CombatWindow(tk.Toplevel):
    def __init__(self, master: tk.Tk, character: Any, enemy: Any, combat_system: Any, on_combat_end: Callable):
        super().__init__(master)
        self.title("Combat")
        self.geometry("500x600")
        self.resizable(False, False)
        
        # Make window modal and force it to stay on top
        self.transient(master)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.disable_close)
        self.lift()
        self.focus_force()
        
        self.character = character
        self.enemy = enemy
        self.combat_system = combat_system
        self.on_combat_end = on_combat_end
        self.combat_ended = False
        
        # Store button references
        self.attack_button = None
        self.item_button = None
        self.flee_button = None
        
        self.setup_ui()
        self.update_stats()
        
        # Start with a combat initiation message
        self.log_message(f"Combat initiated between {self.character.name} and {self.enemy.name}!")
        self.log_message("-" * 50)

    def disable_close(self):
        """Prevent the window from being closed by the X button"""
        pass
        
    def setup_ui(self):
        # Main container with padding
        main_container = ttk.Frame(self, padding="5")
        main_container.pack(fill='both', expand=True)
        
        # Stats Frame
        self.stats_frame = ttk.LabelFrame(main_container, text="Combat Stats", padding="5")
        self.stats_frame.pack(fill='x', pady=(0, 5))
        
        # Character stats
        char_frame = ttk.Frame(self.stats_frame)
        char_frame.pack(fill='x', pady=2)
        ttk.Label(char_frame, text="Player:", width=10).pack(side='left')
        self.character_stats = ttk.Label(char_frame, text="")
        self.character_stats.pack(side='left', fill='x', expand=True)
        
        # Enemy stats
        enemy_frame = ttk.Frame(self.stats_frame)
        enemy_frame.pack(fill='x', pady=2)
        ttk.Label(enemy_frame, text="Enemy:", width=10).pack(side='left')
        self.enemy_stats = ttk.Label(enemy_frame, text="")
        self.enemy_stats.pack(side='left', fill='x', expand=True)
        
        # Combat Log Frame with Scrollbar
        self.log_frame = ttk.LabelFrame(main_container, text="Combat Log", padding="5")
        self.log_frame.pack(fill='both', expand=True, pady=(0, 5))
        
        log_scroll = ttk.Scrollbar(self.log_frame)
        log_scroll.pack(side='right', fill='y')
        
        self.combat_log = tk.Text(
            self.log_frame,
            height=20,
            wrap='word',
            yscrollcommand=log_scroll.set,
            background='white',
            font=('Courier', 10)
        )
        self.combat_log.pack(fill='both', expand=True)
        log_scroll.config(command=self.combat_log.yview)
        
        # Action Buttons Frame
        self.actions_frame = ttk.LabelFrame(main_container, text="Actions", padding="5")
        self.actions_frame.pack(fill='x')
        
        # Action buttons
        button_frame = ttk.Frame(self.actions_frame)
        button_frame.pack(fill='x', expand=True)
        
        self.attack_button = ttk.Button(
            button_frame,
            text="Attack",
            command=self.handle_attack,
            width=20
        )
        self.attack_button.pack(side='left', padx=5)
        
        self.item_button = ttk.Button(
            button_frame,
            text="Use Item",
            command=self.show_item_selection,
            width=20
        )
        self.item_button.pack(side='left', padx=5)
        
        self.flee_button = ttk.Button(
            button_frame,
            text="Flee",
            command=self.handle_flee,
            width=20
        )
        self.flee_button.pack(side='left', padx=5)
        
    def update_stats(self):
        char_attack = self.character.calculate_total_attack()
        char_defense = self.character.calculate_total_defense()
        self.character_stats.config(
            text=f"HP: {self.character.current_health}/{self.character.max_health} "
                 f"ATK: {char_attack} DEF: {char_defense}"
        )
        
        self.enemy_stats.config(
            text=f"HP: {self.enemy.current_health}/{self.enemy.health} "
                 f"ATK: {self.enemy.attack} DEF: {self.enemy.defense}"
        )
        
    def log_message(self, message: str):
        self.combat_log.insert('end', f"{message}\n")
        self.combat_log.see('end')
        
    def disable_buttons(self):
        self.attack_button.config(state='disabled')
        self.item_button.config(state='disabled')
        self.flee_button.config(state='disabled')
        
    def enable_buttons(self):
        if not self.combat_ended:
            self.attack_button.config(state='normal')
            self.item_button.config(state='normal')
            self.flee_button.config(state='normal')

    def show_item_selection(self):
        usable_items = [
            item for item in self.character.inventory 
            if item['type'] == 'consumable'
        ]
        
        if not usable_items:
            self.log_message("\nNo usable items in inventory!")
            return
            
        # Create item selection window
        item_window = tk.Toplevel(self)
        item_window.title("Select Item")
        item_window.geometry("300x400")
        item_window.transient(self)
        item_window.grab_set()
        
        # Create scrollable frame for items
        canvas = tk.Canvas(item_window)
        scrollbar = ttk.Scrollbar(item_window, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Add items to scrollable frame
        for item in usable_items:
            item_frame = ttk.Frame(scrollable_frame)
            item_frame.pack(fill='x', padx=5, pady=2)
            
            effect_desc = ""
            if 'effect' in item and item['effect'].startswith('heal_'):
                try:
                    heal_amount = int(item['effect'].split('_')[1])
                    effect_desc = f" (Heals {heal_amount} HP)"
                except (IndexError, ValueError):
                    effect_desc = ""
            
            item_info = f"{item['name']}{effect_desc}"
            ttk.Label(item_frame, text=item_info).pack(side='left', padx=5)
            ttk.Button(
                item_frame,
                text="Use",
                command=lambda i=item: self.use_selected_item(i, item_window)
            ).pack(side='right', padx=5)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def use_selected_item(self, item: Dict, window: tk.Toplevel):
        window.destroy()
        self.disable_buttons()
        
        success = False
        if item['type'] == 'consumable':
            success = self.character.use_healing_potion(item)
            
            if success:
                heal_amount = int(item['effect'].split('_')[1])
                self.log_message(f"\n{self.character.name} used {item['name']} and healed for {heal_amount} HP!")
                self.update_stats()
                # Process enemy turn after using item
                self.after(1000, self.process_enemy_turn)
            else:
                self.log_message(f"\nFailed to use {item['name']}!")
                self.enable_buttons()
        
        # Log the attempt
        logging.info(f"Combat item use attempt - Item: {item['name']}, Success: {success}")
        
        # Check combat status
        is_ended, outcome = self.combat_system.check_combat_status(self.character, self.enemy)
        if is_ended:
            self.handle_combat_end(outcome)
        elif not success:
            self.enable_buttons()
        
    def handle_attack(self):
        self.disable_buttons()
        
        # Process player's attack
        result = self.combat_system.process_turn(
            self.character,
            self.enemy,
            CombatAction(type='attack')
        )
        
        # Log all messages from the combat system
        self.log_message("\n=== Player Turn ===")
        for message in result['messages']:
            self.log_message(message)
            
        self.update_stats()
        
        # Check if enemy is defeated
        is_ended, outcome = self.combat_system.check_combat_status(self.character, self.enemy)
        if is_ended:
            self.handle_combat_end(outcome)
            return
            
        # Process enemy's turn after a short delay
        self.after(1000, self.process_enemy_turn)
        
    def process_enemy_turn(self):
        self.log_message("\n=== Enemy Turn ===")
        result = self.combat_system.process_turn(
            self.enemy,
            self.character,
            CombatAction(type='attack')
        )
        
        for message in result['messages']:
            self.log_message(message)
            
        self.update_stats()
        
        # Check combat status after enemy turn
        is_ended, outcome = self.combat_system.check_combat_status(self.character, self.enemy)
        if is_ended:
            self.handle_combat_end(outcome)
        else:
            self.enable_buttons()
            
    def handle_flee(self):
        self.disable_buttons()
        
        self.log_message("\n=== Flee Attempt ===")
        result = self.combat_system.process_turn(
            self.character,
            self.enemy,
            CombatAction(type='flee')
        )
        
        for message in result['messages']:
            self.log_message(message)
            
        if result['fled']:
            self.log_message("\nEscaped successfully!")
            self.after(1500, lambda: self.handle_combat_end('fled'))
        else:
            self.log_message("\nFailed to escape!")
            self.after(1000, self.process_enemy_turn)
            
    def handle_combat_end(self, outcome: str):
        self.combat_ended = True
        self.disable_buttons()
        self.log_message("\n" + "=" * 50)
        
        if outcome == 'victory':
            rewards = self.combat_system.distribute_rewards(self.character, self.enemy)
            self.log_message("\nVictory!")
            self.log_message(f"Gained {rewards['xp']} XP and {rewards['copper']} copper")
            for item in rewards['items']:
                self.log_message(f"Received item: {item}")
        elif outcome == 'defeat':
            self.log_message("\nDefeat... You have been slain!")
        elif outcome == 'fled':
            self.log_message("\nYou have escaped from combat!")
            
        # Add a close button
        ttk.Button(
            self.actions_frame,
            text="Close",
            command=lambda: self.end_combat(outcome)
        ).pack(pady=10)
            
    def end_combat(self, outcome: str):
        self.grab_release()
        self.on_combat_end(outcome)
        self.destroy()