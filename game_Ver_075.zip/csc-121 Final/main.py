# main.py
import tkinter as tk
from tkinter import messagebox, ttk, simpledialog
import logging
import json
import os
from datetime import datetime
import random
from typing import Optional, Dict, Any

from config import WINDOW_WIDTH, WINDOW_HEIGHT, SAVE_DIR
from database import Database
from models.character import Character
from models.enemy import Enemy
from models.dungeon import Dungeon
from models.combat import CombatSystem
from gui.main_window import GameWindow
from gui.combat_window import CombatWindow

class Game:
    def __init__(self):
        self.db = Database()
        self.window: Optional[GameWindow] = None
        self.player: Optional[Character] = None
        self.current_dungeon: Optional[Dungeon] = None
        self.game_state = 'menu'  # menu, playing, combat, inventory
        self.combat_system = CombatSystem()

    def start(self):
        self.window = GameWindow()
        self.setup_menu()
        self.bind_keys()
        self.window.mainloop()

    def bind_keys(self):
        self.window.bind('<w>', lambda e: self.handle_movement('north'))
        self.window.bind('<s>', lambda e: self.handle_movement('south'))
        self.window.bind('<a>', lambda e: self.handle_movement('west'))
        self.window.bind('<d>', lambda e: self.handle_movement('east'))
        self.window.bind('<i>', lambda e: self.handle_inventory())
        self.window.bind('<Escape>', lambda e: self.handle_pause())

    def setup_menu(self):
        menu_frame = tk.Frame(self.window)
        menu_frame.pack(expand=True)
        
        tk.Button(menu_frame, text="New Game", command=self.new_game).pack(pady=5)
        tk.Button(menu_frame, text="Load Game", command=self.load_game).pack(pady=5)
        tk.Button(menu_frame, text="Quit", command=self.window.quit).pack(pady=5)

    def new_game(self):
        dialog = tk.Toplevel(self.window)
        dialog.title("Create Character")
        dialog.geometry("300x200")
        dialog.transient(self.window)
        dialog.grab_set()
        
        ttk.Label(dialog, text="Character Name:").pack(pady=5)
        name_entry = ttk.Entry(dialog)
        name_entry.pack(pady=5)
        
        ttk.Label(dialog, text="Age:").pack(pady=5)
        age_entry = ttk.Entry(dialog)
        age_entry.pack(pady=5)
        
        def create_character():
            name = name_entry.get()
            try:
                age = int(age_entry.get())
                if 1 <= age <= 100:
                    dialog.destroy()
                    self.player = Character(name=name, age=age)
                    self.current_dungeon = Dungeon(tier=1)
                    self.start_game()
                else:
                    messagebox.showerror("Error", "Age must be between 1 and 100")
            except ValueError:
                messagebox.showerror("Error", "Age must be a number")
                
        ttk.Button(dialog, text="Create", command=create_character).pack(pady=20)

    def load_game(self):
        try:
            save_files = [f for f in os.listdir(SAVE_DIR) if f.endswith('.json')]
            if not save_files:
                messagebox.showinfo("Load Game", "No saved games found.")
                return

            save_file = simpledialog.askstring(
                "Load Game",
                "Enter save file name:",
                initialvalue=save_files[0]
            )
            
            if not save_file:
                return

            with open(os.path.join(SAVE_DIR, save_file), 'r') as f:
                save_data = json.load(f)

            if not self.validate_save_data(save_data):
                raise ValueError("Invalid save file format")

            self.player = Character(**save_data['player'])
            self.current_dungeon = Dungeon(**save_data['dungeon'])
            self.start_game()

        except Exception as e:
            logging.error(f"Error loading game: {str(e)}")
            messagebox.showerror("Error", f"Failed to load game: {str(e)}")

    def validate_save_data(self, save_data: Dict[str, Any]) -> bool:
        required_keys = {'player', 'dungeon'}
        player_keys = {'name', 'age', 'tier', 'xp', 'current_health', 'inventory'}
        dungeon_keys = {'tier', 'size', 'player_pos', 'rooms'}
        
        if not all(key in save_data for key in required_keys):
            return False
        if not all(key in save_data['player'] for key in player_keys):
            return False
        if not all(key in save_data['dungeon'] for key in dungeon_keys):
            return False
        return True

    def save_game(self):
        try:
            if not self.player or not self.current_dungeon:
                raise ValueError("No active game to save")

            save_data = {
                'player': {
                    'name': self.player.name,
                    'age': self.player.age,
                    'tier': self.player.tier,
                    'xp': self.player.xp,
                    'current_health': self.player.current_health,
                    'inventory': self.player.inventory,
                    'equipped_weapon': self.player.equipped_weapon,
                    'equipped_armor': self.player.equipped_armor,
                    'equipped_shield': self.player.equipped_shield,
                    'money': self.player.money
                },
                'dungeon': self.current_dungeon.to_dict()
            }

            filename = f"{self.player.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(os.path.join(SAVE_DIR, filename), 'w') as f:
                json.dump(save_data, f, indent=2)

            logging.info(f"Game saved: {filename}")
            messagebox.showinfo("Save Game", "Game saved successfully!")

        except Exception as e:
            logging.error(f"Error saving game: {str(e)}")
            messagebox.showerror("Error", f"Failed to save game: {str(e)}")

    def start_game(self):
        self.game_state = 'playing'
        self.window.clear_menu()
        self.window.setup_game_ui()
        self.update_display()

    def update_display(self):
        if not self.window or not self.player or not self.current_dungeon:
            return
        self.window.update_game_view(self.current_dungeon, self.player)
        self.window.update_stats_view(self.player)

    def handle_movement(self, direction: str):
        if self.game_state != 'playing' or not self.current_dungeon:
            return

        if self.current_dungeon.move_player(direction):
            current_room = self.current_dungeon.get_current_room()
            if current_room.enemies and not current_room.is_cleared:
                self.start_combat(current_room.enemies[0])
            self.update_display()

    def handle_pause(self):
        if self.game_state != 'playing':
            return
        self.window.show_pause_menu()

    def start_combat(self, enemy: Enemy):
        if not self.window or not self.player:
            return
            
        self.game_state = 'combat'
        combat_window = CombatWindow(
            self.window,
            self.player,
            enemy,
            self.combat_system,
            self.handle_combat_end
        )

    def handle_combat_end(self, outcome: str):
        if not self.current_dungeon:
            return
            
        self.game_state = 'playing'
        current_room = self.current_dungeon.get_current_room()

        if outcome == 'victory':
            current_room.is_cleared = True
            current_room.enemies = []
        elif outcome == 'fled':
            self.current_dungeon.move_player_random_adjacent()

        self.update_display()

    def handle_inventory(self):
        if self.game_state == 'combat' or not self.window or not self.player:
            return

        self.game_state = 'inventory'
        self.window.show_inventory_ui(self.player)

    def quit_game(self):
        if messagebox.askyesno("Quit Game", "Do you want to save before quitting?"):
            self.save_game()
        if self.window:
            self.window.quit()

def main():
    try:
        game = Game()
        game.start()
    except Exception as e:
        logging.critical(f"Critical error in main game loop: {str(e)}")
        messagebox.showerror("Critical Error", f"A critical error occurred: {str(e)}")

if __name__ == "__main__":
    main()