import tkinter as tk
from tkinter import messagebox, simpledialog
import logging
import json
import os
from datetime import datetime
import random

from config import WINDOW_WIDTH, WINDOW_HEIGHT, SAVE_DIR
from database import Database
from models.character import Character
from models.enemy import Enemy
from models.dungeon import Dungeon
from models.combat import CombatSystem
from gui.main_window import GameWindow
from gui.combat_window import CombatWindow

class Game:
    def __init__(self):
        self.db = Database()
        self.window = None
        self.player = None
        self.current_dungeon = None
        self.game_state = 'menu'
        self.combat_system = CombatSystem()

    def start(self):
        self.window = GameWindow()
        self.setup_menu()
        self.window.mainloop()

    def setup_menu(self):
        menu_frame = tk.Frame(self.window)
        menu_frame.pack(expand=True)

        tk.Button(menu_frame, text="New Game", command=self.new_game).pack(pady=5)
        tk.Button(menu_frame, text="Load Game", command=self.load_game).pack(pady=5)
        tk.Button(menu_frame, text="Quit", command=self.window.quit).pack(pady=5)

    def new_game(self):
        name = simpledialog.askstring("New Game", "Enter your hero's name:")
        if not name:
            return

        age = simpledialog.askinteger("New Game", "Enter your hero's age:", minvalue=1, maxvalue=100)
        if not age:
            return

        try:
            self.player = Character(name=name, age=age)
            self.current_dungeon = Dungeon(tier=1)
            self.start_game()
        except Exception as e:
            logging.error(f"Error creating new game: {str(e)}")
            messagebox.showerror("Error", f"Failed to create new game: {str(e)}")

    def load_game(self):
        try:
            save_files = [f for f in os.listdir(SAVE_DIR) if f.endswith('.json')]
            if not save_files:
                messagebox.showinfo("Load Game", "No saved games found.")
                return

            save_file = simpledialog.askstring(
                "Load Game",
                "Enter save file name:",
                initialvalue=save_files[0]
            )
            
            if not save_file:
                return

            with open(os.path.join(SAVE_DIR, save_file), 'r') as f:
                save_data = json.load(f)

            self.player = Character(**save_data['player'])
            self.current_dungeon = Dungeon(**save_data['dungeon'])
            self.start_game()

        except Exception as e:
            logging.error(f"Error loading game: {str(e)}")
            messagebox.showerror("Error", f"Failed to load game: {str(e)}")

    def save_game(self):
        try:
            save_data = {
                'player': {
                    'name': self.player.name,
                    'age': self.player.age,
                    'tier': self.player.tier,
                    'xp': self.player.xp,
                    'current_health': self.player.current_health,
                    'inventory': self.player.inventory,
                    'equipped_weapon': self.player.equipped_weapon,
                    'equipped_armor': self.player.equipped_armor,
                    'equipped_shield': self.player.equipped_shield
                },
                'dungeon': self.current_dungeon.to_dict()
            }

            filename = f"{self.player.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(os.path.join(SAVE_DIR, filename), 'w') as f:
                json.dump(save_data, f)

            logging.info(f"Game saved: {filename}")
            messagebox.showinfo("Save Game", "Game saved successfully!")

        except Exception as e:
            logging.error(f"Error saving game: {str(e)}")
            messagebox.showerror("Error", f"Failed to save game: {str(e)}")

    def start_game(self):
        self.game_state = 'playing'
        self.window.clear_menu()
        self.window.setup_game_ui()
        self.window.bind_keys()
        self.update_display()

    def update_display(self):
        self.window.update_game_view(self.current_dungeon, self.player)
        self.window.update_stats_view(self.player)

    def handle_movement(self, direction):
        if self.game_state != 'playing':
            return

        if self.current_dungeon.move_player(direction):
            current_room = self.current_dungeon.get_current_room()
            if current_room.enemies and not current_room.is_cleared:
                self.start_combat(current_room.enemies[0])
            self.update_display()

    def start_combat(self, enemy):
        self.game_state = 'combat'
        combat_window = CombatWindow(
            self.window,
            self.player,
            enemy,
            self.combat_system,
            self.handle_combat_end
        )

    def handle_combat_end(self, outcome):
        self.game_state = 'playing'
        current_room = self.current_dungeon.get_current_room()

        if outcome == 'victory':
            current_room.is_cleared = True
            current_room.enemies = []
        elif outcome == 'fled':
            available_directions = [
                dir for dir, has_door in current_room.doors.items() 
                if has_door
            ]
            if available_directions:
                self.handle_movement(random.choice(available_directions))

        self.update_display()

    def handle_inventory(self):
        if self.game_state == 'combat':
            return

        self.game_state = 'inventory'
        self.window.show_inventory_ui(self.player)

    def quit_game(self):
        if messagebox.askyesno("Quit Game", "Do you want to save before quitting?"):
            self.save_game()
        self.window.quit()

def main():
    try:
        game = Game()
        game.start()
    except Exception as e:
        logging.critical(f"Critical error in main game loop: {str(e)}")
        messagebox.showerror("Critical Error", f"A critical error occurred: {str(e)}")

if __name__ == "__main__":
    main()