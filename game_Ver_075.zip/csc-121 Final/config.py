import os
import logging
from datetime import datetime
from typing import Final

# Directory Configuration
BASE_DIR: Final = os.path.dirname(os.path.abspath(__file__))
DATA_DIR: Final = os.path.join(BASE_DIR, 'data')
SAVE_DIR: Final = os.path.join(BASE_DIR, 'saves')
LOG_DIR: Final = os.path.join(BASE_DIR, 'logs')

# Initialize directories
for directory in [DATA_DIR, SAVE_DIR, LOG_DIR]:
    os.makedirs(directory, exist_ok=True)

# Window Configuration
WINDOW_WIDTH: Final = 800
WINDOW_HEIGHT: Final = 640
WINDOW_TITLE: Final = "Dungeon RPG"

# Game Constants
VISIBLE_RANGE: Final = 4
CAMP_HEAL_RATE: Final = 5
FLEE_BASE_CHANCE: Final = 0.3
CRITICAL_HIT_CHANCE: Final = 0.15
CRITICAL_HIT_MULTIPLIER: Final = 2.0  # Changed from 1.5 to 2.0 for double damage

# Enemy spawn rates
ENEMY_SPAWN_CHANCE: Final = 0.4
COMMON_DROP_CHANCE: Final = 0.6
RARE_DROP_CHANCE: Final = 0.1

# Logging Configuration
LOG_FILE = os.path.join(LOG_DIR, f'game_log_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)