# database.py
import csv
import pandas as pd
from typing import Dict, Optional, Any
import os
from config import DATA_DIR
import logging

class Database:
    _instance = None

    def __new__(cls) -> 'Database':
        if cls._instance is None:
            cls._instance = super(Database, cls).__new__(cls)
            cls._instance.initialize()
        return cls._instance

    def initialize(self) -> None:
        self.data_files = {
            'items': os.path.join(DATA_DIR, 'items.csv'),
            'enemies': os.path.join(DATA_DIR, 'enemies.csv'),
            'player_tiers': os.path.join(DATA_DIR, 'player_tiers.csv')
        }
        self._verify_data_files()

    def _verify_data_files(self) -> None:
        for file_name, file_path in self.data_files.items():
            if not os.path.exists(file_path):
                logging.error(f"Missing data file: {file_path}")
                raise FileNotFoundError(f"Required data file missing: {file_name}")

    def load_data(self, table_name: str) -> pd.DataFrame:
        try:
            return pd.read_csv(self.data_files[table_name])
        except Exception as e:
            logging.error(f"Error loading {table_name}: {str(e)}")
            return pd.DataFrame()

    def save_data(self, table_name: str, data: pd.DataFrame) -> None:
        try:
            data.to_csv(self.data_files[table_name], index=False)
            logging.info(f"Successfully saved data to {table_name}")
        except Exception as e:
            logging.error(f"Error saving {table_name}: {str(e)}")
            raise

    def get_item(self, item_name: str) -> Optional[Dict[str, Any]]:
        """Get complete item data by name."""
        items_df = self.load_data('items')
        try:
            item = items_df[items_df['name'] == item_name].iloc[0]
            return {
                'name': item['name'],
                'type': item['type'],
                'base_damage_min': float(item['base_damage_min']) if pd.notna(item['base_damage_min']) else 0,
                'base_damage_max': float(item['base_damage_max']) if pd.notna(item['base_damage_max']) else 0,
                'base_defense': float(item['base_defense']) if pd.notna(item['base_defense']) else 0,
                'price_copper': int(item['price_copper']) if pd.notna(item['price_copper']) else 0,
                'tier': int(item['tier']) if pd.notna(item['tier']) else 1,
                'durability': int(item['durability']) if pd.notna(item['durability']) else 100,
                'effect': item['effect'] if pd.notna(item['effect']) else 'none'
            }
        except (IndexError, KeyError) as e:
            logging.warning(f"Item not found or invalid data: {item_name} - {str(e)}")
            return None

    def get_enemy(self, enemy_name: str) -> Optional[Dict[str, Any]]:
        """Get complete enemy data by name."""
        enemies_df = self.load_data('enemies')
        try:
            enemy = enemies_df[enemies_df['name'] == enemy_name].iloc[0]
            return {
                'name': enemy['name'],
                'tier': int(enemy['tier']) if pd.notna(enemy['tier']) else 1,
                'attack': int(enemy['attack']) if pd.notna(enemy['attack']) else 0,
                'defense': int(enemy['defense']) if pd.notna(enemy['defense']) else 0,
                'health': int(enemy['health']) if pd.notna(enemy['health']) else 10,
                'xp_value': int(enemy['xp_value']) if pd.notna(enemy['xp_value']) else 1,
                'min_copper': int(enemy['min_copper']) if pd.notna(enemy['min_copper']) else 0,
                'max_copper': int(enemy['max_copper']) if pd.notna(enemy['max_copper']) else 0,
                'common_drops': enemy['common_drops'] if pd.notna(enemy['common_drops']) else '',
                'rare_drops': enemy['rare_drops'] if pd.notna(enemy['rare_drops']) else '',
                'spawn_chance': float(enemy['spawn_chance']) if pd.notna(enemy['spawn_chance']) else 0.1
            }
        except (IndexError, KeyError) as e:
            logging.warning(f"Enemy not found or invalid data: {enemy_name} - {str(e)}")
            return None

    def get_tier_data(self, tier: int) -> Optional[Dict[str, Any]]:
        """Get complete tier data for the specified tier level."""
        tiers_df = self.load_data('player_tiers')
        try:
            tier_data = tiers_df[tiers_df['tier'] == tier].iloc[0]
            return {
                'tier': int(tier_data['tier']),
                'title': tier_data['title'],
                'attack': int(tier_data['attack']) if pd.notna(tier_data['attack']) else 1,
                'defense': int(tier_data['defense']) if pd.notna(tier_data['defense']) else 1,
                'health': int(tier_data['health']) if pd.notna(tier_data['health']) else 20,
                'min_xp': int(tier_data['min_xp']) if pd.notna(tier_data['min_xp']) else 0,
                'weapon': tier_data['weapon'] if pd.notna(tier_data['weapon']) else None,
                'armor': tier_data['armor'] if pd.notna(tier_data['armor']) else None,
                'special_ability': tier_data['special_ability'] if pd.notna(tier_data['special_ability']) else 'none'
            }
        except (IndexError, KeyError) as e:
            logging.warning(f"Tier data not found or invalid: {tier} - {str(e)}")
            return None

    def get_all_items_by_tier(self, tier: int) -> pd.DataFrame:
        """Get all items available for a specific tier."""
        items_df = self.load_data('items')
        return items_df[items_df['tier'] <= tier].copy()

    def get_all_enemies_by_tier(self, tier: int) -> pd.DataFrame:
        """Get all enemies that can appear in a specific tier."""
        enemies_df = self.load_data('enemies')
        return enemies_df[enemies_df['tier'] <= tier].copy()

    def update_item(self, item_name: str, updates: Dict[str, Any]) -> None:
        """Update specific attributes of an item."""
        items_df = self.load_data('items')
        idx = items_df[items_df['name'] == item_name].index
        if len(idx) == 0:
            raise ValueError(f"Item not found: {item_name}")
        
        for key, value in updates.items():
            if key not in items_df.columns:
                raise ValueError(f"Invalid item attribute: {key}")
            items_df.loc[idx, key] = value
            
        self.save_data('items', items_df)
        logging.info(f"Updated item {item_name} with {updates}")