from dataclasses import dataclass
from typing import Optional, Dict, List, Any, Tuple
from database import Database
import random
import logging

@dataclass
class Enemy:
    """
    Represents an enemy character.
    """
    name: str
    tier: int
    current_health: Optional[int] = None
    attack: int = 0
    defense: int = 0
    health: int = 0
    xp_value: int = 0
    min_copper: int = 0
    max_copper: int = 0
    common_drops: List[str] = None
    rare_drops: List[str] = None
    is_player: bool = False  # Added to identify non-player characters

    def __post_init__(self):
        """
        Initialize enemy stats after creation.
        """
        self._load_stats()
        if self.current_health is None:
            self.current_health = self.health
        if self.common_drops is None:
            self.common_drops = []
        if self.rare_drops is None:
            self.rare_drops = []

    def _load_stats(self) -> None:
        """
        Load enemy stats from the database.
        """
        db = Database()
        enemy_data = db.get_enemy(self.name)
        if not enemy_data:
            logging.error(f"Failed to load enemy data for {self.name}")
            raise ValueError(f"Invalid enemy: {self.name}")

        self.attack = enemy_data['attack']
        self.defense = enemy_data['defense']
        self.health = enemy_data['health']
        self.xp_value = enemy_data['xp_value']
        self.min_copper = enemy_data['min_copper']
        self.max_copper = enemy_data['max_copper']
        self.common_drops = enemy_data['common_drops'].split(',') if enemy_data['common_drops'] else []
        self.rare_drops = enemy_data['rare_drops'].split(',') if enemy_data['rare_drops'] else []

    def take_damage(self, damage: int) -> bool:
        """
        Take damage and return whether still alive.
        
        Args:
            damage: The amount of damage to take.
            
        Returns:
            True if the enemy is still alive, False otherwise.
        """
        self.current_health = max(0, self.current_health - damage)
        logging.info(f"{self.name} took {damage} damage. Health: {self.current_health}/{self.health}")
        return self.current_health > 0

    def is_defeated(self) -> bool:
        """
        Check if the enemy is defeated.
        
        Returns:
            True if the enemy is defeated, False otherwise.
        """
        return self.current_health <= 0

    def get_drops(self) -> List[Tuple[str, Any]]:
        """
        Generate loot drops with improved variety and chances.
        
        Returns:
            A list of loot drops as tuples (drop_type, value).
        """
        drops = []
        db = Database()
        
        # Base money drops with bonus chance
        base_copper = random.randint(self.min_copper, self.max_copper)
        if random.random() < 0.2:  # 20% chance for bonus money
            bonus_multiplier = random.uniform(1.5, 3.0)
            base_copper = int(base_copper * bonus_multiplier)
        drops.append(('copper', base_copper))
        
        # Legendary drop chance (tier 6 items)
        if random.random() < 0.02:  # 2% chance for legendary item
            legendary_items = db.get_all_items_by_tier(6)
            if not legendary_items.empty:
                item = legendary_items.sample(n=1).iloc[0]
                drops.append(('item', item['name']))
                logging.info(f"Legendary item dropped: {item['name']}")

        # Rare drop chance (items from higher tiers)
        if random.random() < 0.15:  # 15% chance for rare item
            max_tier = min(self.tier + 2, 5)  # Up to 2 tiers higher, max tier 5
            rare_items = db.get_all_items_by_tier(max_tier)
            if not rare_items.empty:
                item = rare_items.sample(n=1).iloc[0]
                drops.append(('item', item['name']))
                logging.info(f"Rare item dropped: {item['name']}")

        # Common drops with improved variety
        if random.random() < 0.6:  # 60% chance for common drop
            drop_pool = []
            
            # Add tier-appropriate items
            tier_items = db.get_all_items_by_tier(self.tier)
            if not tier_items.empty:
                drop_pool.extend(tier_items['name'].tolist())
            
            # Add specific common drops
            if self.common_drops:
                drop_pool.extend(self.common_drops)
            
            if drop_pool:
                item_name = random.choice(drop_pool)
                drops.append(('item', item_name))
                logging.info(f"Common item dropped: {item_name}")

        # Extra drops based on enemy tier
        extra_drop_chance = 0.1 * self.tier  # Higher tier = more chances
        while random.random() < extra_drop_chance and extra_drop_chance > 0:
            tier_items = db.get_all_items_by_tier(self.tier)
            if not tier_items.empty:
                item = tier_items.sample(n=1).iloc[0]
                drops.append(('item', item['name']))
                logging.info(f"Extra item dropped: {item['name']}")
            extra_drop_chance -= 0.1

        logging.info(f"{self.name} dropped: {drops}")
        return drops

    def calculate_total_attack(self) -> int:
        """
        Calculate total attack (for combat system compatibility).
        
        Returns:
            The total attack value.
        """
        return self.attack

    def calculate_total_defense(self) -> int:
        """
        Calculate total defense (for combat system compatibility).
        
        Returns:
            The total defense value.
        """
        return self.defense

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert enemy data to a dictionary for saving.
        
        Returns:
            The enemy data as a dictionary.
        """
        return {
            'name': self.name,
            'tier': self.tier,
            'current_health': self.current_health,
            'attack': self.attack,
            'defense': self.defense,
            'health': self.health,
            'xp_value': self.xp_value,
            'min_copper': self.min_copper,
            'max_copper': self.max_copper,
            'common_drops': self.common_drops,
            'rare_drops': self.rare_drops
        }

    @staticmethod
    def get_random_enemy(tier: int) -> 'Enemy':
        """
        Create a random enemy of the specified tier.
        
        Args:
            tier: The tier of the enemy.
            
        Returns:
            A random enemy of the specified tier.
        """
        db = Database()
        tier_enemies = db.get_all_enemies_by_tier(tier)
        if tier_enemies.empty:
            raise ValueError(f"No enemies found for tier {tier}")
            
        # Weight probabilities based on spawn_chance
        total_chance = tier_enemies['spawn_chance'].sum()
        roll = random.random() * total_chance
        cumulative = 0
        
        for _, enemy in tier_enemies.iterrows():
            cumulative += enemy['spawn_chance']
            if roll <= cumulative:
                return Enemy(
                    name=enemy['name'],
                    tier=enemy['tier']
                )
        
        # Fallback to random selection if weighting fails
        enemy_data = tier_enemies.sample().iloc[0]
        return Enemy(
            name=enemy_data['name'],
            tier=enemy_data['tier']
        )