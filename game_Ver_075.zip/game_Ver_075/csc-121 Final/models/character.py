from dataclasses import dataclass, field
from typing import List, Dict, Optional
import logging
from database import Database

@dataclass
class Character:
    """
    Represents a character in the game.
    """
    name: str
    age: int
    tier: int = 1
    xp: int = 0
    current_health: Optional[int] = None
    inventory: List[Dict] = field(default_factory=list)
    equipped_weapon: Optional[Dict] = None
    equipped_armor: Optional[Dict] = None
    equipped_shield: Optional[Dict] = None
    money: int = 0
    is_player: bool = True  # Added to identify player characters
    
    def __post_init__(self):
        """
        Initialize character stats after creation.
        """
        self._load_stats()
        if self.current_health is None:
            self.current_health = self.max_health

        # Initialize starting inventory for new characters
        if not self.inventory and not self.equipped_weapon:  # Check if this is a new character
            self._initialize_starting_equipment()

    def _initialize_starting_equipment(self):
        """
        Give starting equipment to new characters.
        """
        db = Database()
        
        # Add 5 health potions
        health_potion = db.get_item("Lesser Health Potion")
        if health_potion:
            for _ in range(5):
                self.inventory.append(health_potion.copy())
                
        # Add starting money
        self.money = 100  # Starting money in copper

        # Get and equip initial gear from tier data
        tier_data = db.get_tier_data(self.tier)
        if tier_data:
            # Equip starting weapon
            if 'weapon' in tier_data and tier_data['weapon']:
                weapon = db.get_item(tier_data['weapon'])
                if weapon:
                    self.equipped_weapon = weapon
                    logging.info(f"Equipped starting weapon: {weapon['name']}")

            # Equip starting armor
            if 'armor' in tier_data and tier_data['armor']:
                armor = db.get_item(tier_data['armor'])
                if armor:
                    self.equipped_armor = armor
                    logging.info(f"Equipped starting armor: {armor['name']}")

    def _load_stats(self) -> None:
        """
        Load base stats and initial equipment for the character tier.
        """
        db = Database()
        tier_data = db.get_tier_data(self.tier)
        if not tier_data:
            logging.error(f"Failed to load tier {self.tier} data for character {self.name}")
            raise ValueError(f"Invalid tier: {self.tier}")

        # Load base stats
        self.title = tier_data['title']
        self.base_attack = tier_data['attack']
        self.base_defense = tier_data['defense']
        self.max_health = tier_data['health']
        self.special_ability = tier_data['special_ability']

    def add_xp(self, xp_amount: int) -> None:
        """
        Add experience points and check for level up.
        
        Args:
            xp_amount: The amount of XP to add.
        """
        self.xp += xp_amount
        logging.info(f"{self.name} gained {xp_amount} XP. Total: {self.xp}")
        self._check_level_up()

    def _check_level_up(self) -> None:
        """
        Check and process level up if applicable.
        """
        db = Database()
        next_tier = self.tier + 1
        next_tier_data = db.get_tier_data(next_tier)
        
        if next_tier_data and self.xp >= next_tier_data['min_xp']:
            self._level_up()

    def _level_up(self) -> None:
        """
        Process level up and adjust stats.
        """
        self.tier += 1
        old_health = self.max_health
        self._load_stats()
        # Heal proportionally when leveling up
        health_percent = self.current_health / old_health
        self.current_health = int(self.max_health * health_percent)
        logging.info(f"{self.name} leveled up to tier {self.tier} ({self.title})")

    def take_damage(self, damage: int) -> bool:
        """
        Take damage and return whether still alive.
        
        Args:
            damage: The amount of damage to take.
            
        Returns:
            True if the character is still alive, False otherwise.
        """
        self.current_health = max(0, self.current_health - damage)
        logging.info(f"{self.name} took {damage} damage. Health: {self.current_health}/{self.max_health}")
        return self.current_health > 0

    def heal(self, amount: int) -> int:
        """
        Heal the character.
        
        Args:
            amount: The amount of health to restore.
            
        Returns:
            The actual amount healed.
        """
        old_health = self.current_health
        self.current_health = min(self.max_health, self.current_health + amount)
        actual_heal = self.current_health - old_health
        logging.info(f"{self.name} healed for {actual_heal}. Health: {self.current_health}/{self.max_health}")
        return actual_heal

    def use_healing_potion(self, potion: Dict) -> bool:
        """
        Use a healing potion from inventory.
        
        Args:
            potion: The potion to use.
            
        Returns:
            True if the potion was used successfully, False otherwise.
        """
        if potion['type'] != 'consumable':
            logging.warning(f"Attempted to use non-consumable item as potion: {potion['name']}")
            return False
            
        try:
            heal_amount = int(potion['effect'].split('_')[1])
            self.heal(heal_amount)
            self.remove_item(potion)
            logging.info(f"{self.name} used {potion['name']} and healed for {heal_amount}")
            return True
        except (IndexError, ValueError) as e:
            logging.error(f"Invalid potion effect format: {potion['effect']} - {str(e)}")
            return False

    def add_item(self, item: Dict) -> None:
        """
        Add an item to inventory with proper data loading.
        
        Args:
            item: The item to add.
        """
        if isinstance(item, str):
            # If just a name was passed, get complete item data
            db = Database()
            item_data = db.get_item(item)
            if item_data:
                self.inventory.append(item_data)
                logging.info(f"{self.name} acquired {item_data['name']}")
            else:
                logging.error(f"Failed to load item data for: {item}")
        else:
            # If complete item data was passed, add it directly
            self.inventory.append(item)
            logging.info(f"{self.name} acquired {item['name']}")

    def remove_item(self, item: Dict) -> bool:
        """
        Remove an item from inventory.
        
        Args:
            item: The item to remove.
            
        Returns:
            True if the item was removed successfully, False otherwise.
        """
        try:
            self.inventory.remove(item)
            logging.info(f"{self.name} removed {item['name']} from inventory")
            return True
        except ValueError:
            logging.warning(f"Failed to remove {item['name']} from {self.name}'s inventory - item not found")
            return False

    def equip_item(self, item: Dict) -> bool:
        """
        Equip an item.
        
        Args:
            item: The item to equip.
            
        Returns:
            True if the item was equipped successfully, False otherwise.
        """
        if item['type'] == 'weapon':
            if self.equipped_weapon:
                self.inventory.append(self.equipped_weapon)
            self.equipped_weapon = item
            logging.info(f"{self.name} equipped weapon: {item['name']}")
        elif item['type'] == 'armor':
            if self.equipped_armor:
                self.inventory.append(self.equipped_armor)
            self.equipped_armor = item
            logging.info(f"{self.name} equipped armor: {item['name']}")
        elif item['type'] == 'shield':
            if self.equipped_shield:
                self.inventory.append(self.equipped_shield)
            self.equipped_shield = item
            logging.info(f"{self.name} equipped shield: {item['name']}")
        else:
            return False
        
        self.inventory.remove(item)
        return True

    def calculate_total_attack(self) -> int:
        """
        Calculate total attack including equipment bonuses.
        
        Returns:
            The total attack value.
        """
        total = self.base_attack
        if self.equipped_weapon:
            min_dmg = float(self.equipped_weapon.get('base_damage_min', 0))
            max_dmg = float(self.equipped_weapon.get('base_damage_max', 0))
            total += (min_dmg + max_dmg) / 2
        return int(total)

    def calculate_total_defense(self) -> int:
        """
        Calculate total defense including equipment bonuses.
        
        Returns:
            The total defense value.
        """
        total = self.base_defense
        if self.equipped_armor:
            total += float(self.equipped_armor.get('base_defense', 0))
        if self.equipped_shield:
            total += float(self.equipped_shield.get('base_defense', 0))
        return int(total)

    def get_equipment_display(self) -> Dict[str, str]:
        """
        Get formatted equipment information for display.
        
        Returns:
            A dictionary with display strings for each equipment slot.
        """
        weapon = "None"
        armor = "None"
        shield = "None"
        
        if self.equipped_weapon:
            weapon = f"{self.equipped_weapon['name']} (DMG: {self.equipped_weapon['base_damage_min']}-{self.equipped_weapon['base_damage_max']})"
        if self.equipped_armor:
            armor = f"{self.equipped_armor['name']} (DEF: {self.equipped_armor['base_defense']})"
        if self.equipped_shield:
            shield = f"{self.equipped_shield['name']} (DEF: {self.equipped_shield['base_defense']})"
            
        return {
            'weapon': weapon,
            'armor': armor,
            'shield': shield
        }

    def to_dict(self) -> Dict:
        """
        Convert character data to a dictionary for saving.
        
        Returns:
            The character data as a dictionary.
        """
        return {
            'name': self.name,
            'age': self.age,
            'tier': self.tier,
            'xp': self.xp,
            'current_health': self.current_health,
            'inventory': self.inventory,
            'equipped_weapon': self.equipped_weapon,
            'equipped_armor': self.equipped_armor,
            'equipped_shield': self.equipped_shield,
            'money': self.money
        }

    def get_status_effects(self) -> List[str]:
        """
        Get a list of active status effects on the character.
        
        Returns:
            A list of active status effect names.
        """
        effects = []
        if getattr(self, 'special_ability', 'none') != 'none':
            effects.append(self.special_ability)
        return effects

    def can_afford(self, price: int) -> bool:
        """
        Check if the character can afford an item.
        
        Args:
            price: The price of the item.
            
        Returns:
            True if the character can afford the item, False otherwise.
        """
        return self.money >= price