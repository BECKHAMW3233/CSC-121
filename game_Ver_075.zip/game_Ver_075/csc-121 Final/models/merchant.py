from typing import List, Dict, Any
from database import Database
import random
import logging

class Merchant:
    """
    Represents a merchant in the game.
    """
    def __init__(self):
        """
        Initialize the merchant.
        """
        self._db = Database()
        self._inventory = self._generate_inventory()
        self._refresh_timer = 0  # For periodic inventory refresh
        
    def _generate_inventory(self) -> List[Dict]:
        """
        Generate the merchant's inventory with varied items.
        
        Returns:
            The generated inventory as a list of item dictionaries.
        """
        inventory = []
        try:
            # Get all possible items
            all_items = self._db.get_all_items_by_tier(6)  # Include all tiers
            
            # Ensure we have items
            if all_items.empty:
                logging.error("No items found in database for merchant")
                return inventory

            # Select varied items by type and tier
            for item_type in ['weapon', 'armor', 'shield', 'consumable']:
                type_items = all_items[all_items['type'] == item_type]
                
                # Number of items to select varies by type
                num_items = 5 if item_type == 'consumable' else 3
                
                if not type_items.empty:
                    selected = type_items.sample(n=min(num_items, len(type_items)))
                    inventory.extend(selected.to_dict('records'))

            # Add some random additional items
            remaining_items = all_items.sample(n=5)
            inventory.extend(remaining_items.to_dict('records'))

            # Adjust prices randomly
            for item in inventory:
                price_modifier = random.uniform(0.8, 1.2)  # ±20% price variation
                item['price_copper'] = int(item['price_copper'] * price_modifier)

            logging.info(f"Generated merchant inventory with {len(inventory)} items")
            return inventory

        except Exception as e:
            logging.error(f"Error generating merchant inventory: {str(e)}")
            return []

    def refresh_inventory(self) -> None:
        """
        Refresh the merchant's inventory.
        """
        self._inventory = self._generate_inventory()
        self._refresh_timer = 0
        logging.info("Merchant inventory refreshed")

    def buy_item(self, player: Any, item_name: str) -> bool:
        """
        Handle the player buying an item from the merchant.
        
        Args:
            player: The player character.
            item_name: The name of the item to buy.
            
        Returns:
            True if the item was bought successfully, False otherwise.
        """
        try:
            # Find item in merchant inventory
            item = next((i for i in self._inventory if i['name'] == item_name), None)
            
            if not item:
                logging.warning(f"Item not found in merchant inventory: {item_name}")
                return False
                
            if player.money < item['price_copper']:
                logging.info(f"Player cannot afford item: {item_name}")
                return False
                
            # Process transaction
            player.money -= item['price_copper']
            player.add_item(item)
            self._inventory.remove(item)
            
            logging.info(f"Player bought {item_name} for {item['price_copper']} copper")
            return True
            
        except Exception as e:
            logging.error(f"Error processing buy transaction: {str(e)}")
            return False

    def sell_item(self, player: Any, item: Dict) -> bool:
        """
        Handle the player selling an item to the merchant.
        
        Args:
            player: The player character.
            item: The item to sell.
            
        Returns:
            True if the item was sold successfully, False otherwise.
        """
        try:
            if item not in player.inventory:
                logging.warning(f"Item not found in player inventory: {item['name']}")
                return False
                
            # Calculate sell price (50% of base price)
            sell_price = int(item['price_copper'] * 0.5)
            
            # Process transaction
            player.money += sell_price
            player.remove_item(item)
            
            logging.info(f"Player sold {item['name']} for {sell_price} copper")
            return True
            
        except Exception as e:
            logging.error(f"Error processing sell transaction: {str(e)}")
            return False

    def get_item_value(self, item: Dict) -> int:
        """
        Calculate the sell value of an item.
        
        Args:
            item: The item to calculate the value for.
            
        Returns:
            The sell value of the item.
        """
        return int(item['price_copper'] * 0.5)

    def get_inventory_by_type(self, item_type: str) -> List[Dict]:
        """
        Get filtered inventory by item type.
        
        Args:
            item_type: The type of items to retrieve.
            
        Returns:
            A list of items of the specified type.
        """
        return [item for item in self._inventory if item['type'] == item_type]

    def get_available_types(self) -> List[str]:
        """
        Get a list of available item types in the inventory.
        
        Returns:
            A list of available item types.
        """
        return sorted(list(set(item['type'] for item in self._inventory)))