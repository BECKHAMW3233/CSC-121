from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Any, List
import random
import logging
from config import FLEE_BASE_CHANCE, CRITICAL_HIT_MULTIPLIER
from database import Database

@dataclass
class CombatAction:
    """
    Represents a combat action.
    """
    type: str  # 'attack', 'use_item', 'flee'
    target: Optional[str] = None
    item: Optional[Dict] = None

class CombatSystem:
    """
    Represents the combat system.
    """
    def __init__(self):
        """
        Initialize the combat system.
        """
        self._status_effects: Dict[str, Dict] = {}

    def roll_d20(self) -> int:
        """
        Simulate rolling a 20-sided die.
        
        Returns:
            The result of the die roll.
        """
        return random.randint(1, 20)

    def calculate_hit(self, attacker: Any, defender: Any) -> Tuple[bool, int, bool]:
        """
        Calculate if an attack hits using the D20 system.
        
        Args:
            attacker: The attacking character.
            defender: The defending character.
            
        Returns:
            A tuple of (hit successful, roll value, critical hit).
        """
        roll = self.roll_d20()
        
        # Natural 20 always hits and crits
        if roll == 20:
            return True, roll, True
            
        # Natural 1 always misses
        if roll == 1:
            return False, roll, False
            
        attack_bonus = attacker.calculate_total_attack()
        defense_class = 10 + defender.calculate_total_defense()  # Base AC of 10
        
        # Player advantage: +2 to hit for players
        if hasattr(attacker, 'title'):  # Check if attacker is player
            attack_bonus += 2
            
        return (roll + attack_bonus >= defense_class), roll, False

    def process_turn(self, attacker: Any, defender: Any, action: CombatAction) -> Dict[str, Any]:
        """
        Process a single combat turn.
        
        Args:
            attacker: The attacking character.
            defender: The defending character.
            action: The combat action.
            
        Returns:
            The result of the combat turn.
        """
        result = {
            'success': True,
            'damage_dealt': 0,
            'item_used': None,
            'fled': False,
            'messages': [],
            'roll_info': {}
        }

        if action.type == 'attack':
            hit_success, roll, is_crit = self.calculate_hit(attacker, defender)
            result['roll_info']['hit_roll'] = roll
            result['roll_info']['attack_bonus'] = attacker.calculate_total_attack()
            result['roll_info']['defense_class'] = 10 + defender.calculate_total_defense()
            
            if hit_success:
                damage = self._calculate_damage(attacker, defender, is_crit)
                result['roll_info']['damage_base'] = damage / (CRITICAL_HIT_MULTIPLIER if is_crit else 1)
                result['roll_info']['is_crit'] = is_crit
                
                defender.take_damage(damage)
                result['damage_dealt'] = damage
                
                # Detailed combat message
                crit_text = " **CRITICAL HIT!**" if is_crit else ""
                roll_text = f"[Roll: {roll} + {attacker.calculate_total_attack()} vs AC {result['roll_info']['defense_class']}]"
                
                message = (f"{attacker.name} attacks {defender.name}{crit_text}! "
                          f"{roll_text} "
                          f"Dealing {damage} damage!")
                
                result['messages'].append(message)
                
                # Log the detailed combat information
                logging.info(f"Combat Roll - {attacker.name} vs {defender.name}:")
                logging.info(f"  D20 Roll: {roll}")
                logging.info(f"  Attack Bonus: {attacker.calculate_total_attack()}")
                logging.info(f"  Defense Class: {result['roll_info']['defense_class']}")
                if is_crit:
                    logging.info("  Critical Hit!")
                logging.info(f"  Final Damage: {damage}")
            else:
                result['success'] = False
                miss_reason = "Critical Miss!" if roll == 1 else "Miss!"
                message = f"{attacker.name}'s attack missed! {miss_reason} {roll} + {attacker.calculate_total_attack()} vs AC {result['roll_info']['defense_class']}"
                result['messages'].append(message)
                logging.info(f"Combat Miss - {attacker.name} vs {defender.name}:")
                logging.info(f"  D20 Roll: {roll}")
                logging.info(f"  Required: {result['roll_info']['defense_class']}")

        elif action.type == 'use_item':
            if action.item in attacker.inventory:
                self._apply_item_effect(attacker, action.item)
                attacker.inventory.remove(action.item)
                result['item_used'] = action.item
                result['messages'].append(f"{attacker.name} used {action.item['name']}")

        elif action.type == 'flee':
            flee_roll = self.roll_d20()
            result['roll_info']['flee_roll'] = flee_roll
            flee_dc = 10  # Base difficulty for fleeing
            
            # Player advantage on fleeing
            if hasattr(attacker, 'title'):
                flee_bonus = 2
            else:
                flee_bonus = 0
                
            if flee_roll + flee_bonus >= flee_dc:
                result['fled'] = True
                message = f"{attacker.name} successfully fled! [Roll: {flee_roll} + {flee_bonus} vs DC {flee_dc}]"
                result['messages'].append(message)
                logging.info(f"Flee Success - {attacker.name}:")
                logging.info(f"  D20 Roll: {flee_roll}")
                logging.info(f"  Bonus: {flee_bonus}")
                logging.info(f"  DC: {flee_dc}")
            else:
                result['success'] = False
                message = f"{attacker.name} failed to flee! [Roll: {flee_roll} + {flee_bonus} vs DC {flee_dc}]"
                result['messages'].append(message)
                logging.info(f"Flee Failure - {attacker.name}:")
                logging.info(f"  D20 Roll: {flee_roll}")
                logging.info(f"  Bonus: {flee_bonus}")
                logging.info(f"  DC: {flee_dc}")

        return result

    def _calculate_damage(self, attacker: Any, defender: Any, is_crit: bool = False) -> int:
        """
        Calculate damage using the D20 system.
        
        Args:
            attacker: The attacking character.
            defender: The defending character.
            is_crit: Whether the attack is a critical hit.
            
        Returns:
            The calculated damage.
        """
        base_damage = attacker.calculate_total_attack()
        
        # Roll damage dice based on weapon
        if hasattr(attacker, 'equipped_weapon') and attacker.equipped_weapon:
            min_dmg = float(attacker.equipped_weapon.get('base_damage_min', 1))
            max_dmg = float(attacker.equipped_weapon.get('base_damage_max', 4))
            weapon_damage = random.uniform(min_dmg, max_dmg)
            base_damage += weapon_damage
        
        # Apply defense reduction
        defense = defender.calculate_total_defense()
        damage = max(1, base_damage - (defense / 2))  # Defense reduces damage by half its value
        
        # Critical hits double damage
        if is_crit:
            damage *= CRITICAL_HIT_MULTIPLIER
            
        # Player advantage: 20% bonus damage for players
        if hasattr(attacker, 'title'):
            damage *= 1.2
            
        return int(damage)

    def _apply_item_effect(self, character: Any, item: Dict[str, Any]) -> None:
        """
        Apply the effect of an item.
        
        Args:
            character: The character using the item.
            item: The item being used.
        """
        if 'type' not in item:
            logging.error(f"Item missing 'type' field: {item}")
            return
            
        if item['type'] == 'consumable':
            if 'effect' not in item:
                logging.error(f"Consumable item missing 'effect' field: {item}")
                return
            try:
                effect_type, value = item['effect'].split('_')
                if effect_type == 'heal':
                    heal_amount = int(value)
                    character.heal(heal_amount)
                    logging.info(f"Applied healing effect: {heal_amount}")
            except (IndexError, ValueError) as e:
                logging.error(f"Invalid effect format: {item['effect']} - {str(e)}")
        elif item['type'] == 'buff':
            self._status_effects[character.name] = {
                'effect': item['effect'],
                'duration': item.get('duration', 1)
            }

    def check_combat_status(self, character: Any, enemy: Any) -> Tuple[bool, str]:
        """
        Check if combat has ended and determine the outcome.
        
        Args:
            character: The player character.
            enemy: The enemy character.
            
        Returns:
            A tuple of (combat ended, outcome).
        """
        if character.current_health <= 0:
            return True, 'defeat'
        if enemy.current_health <= 0:
            return True, 'victory'
        return False, ''

    def distribute_rewards(self, character: Any, enemy: Any) -> Dict[str, Any]:
        """
        Calculate and distribute rewards from defeating an enemy.
        
        Args:
            character: The player character.
            enemy: The defeated enemy.
            
        Returns:
            The rewards earned by the player.
        """
        db = Database()
        rewards = {
            'xp': enemy.xp_value,
            'items': [],
            'copper': 0
        }

        # Get drops from enemy
        drops = enemy.get_drops()
        for drop_type, value in drops:
            if drop_type == 'copper':
                rewards['copper'] = value
                character.money += value
            elif drop_type == 'item':
                # Get complete item data from database
                item_data = db.get_item(value)
                if item_data:
                    rewards['items'].append(item_data['name'])
                    character.add_item(item_data)
                else:
                    logging.error(f"Failed to load item data for drop: {value}")

        # Add XP
        character.add_xp(rewards['xp'])
        logging.info(f"Combat rewards distributed: {rewards}")
        return rewards