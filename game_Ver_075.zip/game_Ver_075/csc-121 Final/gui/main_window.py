import tkinter as tk
from tkinter import ttk, messagebox
from typing import Any, Optional, Dict
from config import WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE
import logging

class GameWindow(tk.Tk):
    """
    The main game window class.
    """
    def __init__(self):
        """
        Initialize the game window.
        """
        super().__init__()
        self.title(WINDOW_TITLE)
        self.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.configure(bg='black')
        self._current_frame: Optional[GameFrame] = None
        self._player = None
        self._setup_styles()

    def _setup_styles(self):
        """
        Set up the styles for the game window.
        """
        style = ttk.Style()
        style.configure('Game.TFrame', background='black')
        style.configure('Game.TLabel', background='black', foreground='white')
        style.configure('Game.TButton', padding=5)
        style.configure('Equipment.TLabel', background='dark blue', foreground='white', padding=5)
        style.configure('Merchant.TFrame', background='brown')

    def clear_menu(self):
        """
        Clear the current menu frame.
        """
        if self._current_frame:
            self._current_frame.destroy()

    def setup_game_ui(self):
        """
        Set up the game user interface.
        """
        self.clear_menu()
        self._current_frame = GameFrame(self)
        self._current_frame.pack(expand=True, fill='both')
        
        menu_bar = tk.Menu(self)
        self.config(menu=menu_bar)
        
        game_menu = tk.Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Game", menu=game_menu)
        game_menu.add_command(label="Save Game (Ctrl+S)", command=lambda: self.event_generate("<<SaveGame>>"))
        game_menu.add_command(label="Load Game", command=lambda: self.event_generate("<<LoadGame>>"))
        game_menu.add_separator()
        game_menu.add_command(label="Quit", command=lambda: self.event_generate("<<QuitGame>>"))

    def bind_keys(self):
        """
        Bind the movement keys.
        """
        self.bind('<w>', lambda e: self.event_generate("<<MoveNorth>>"))
        self.bind('<s>', lambda e: self.event_generate("<<MoveSouth>>"))
        self.bind('<a>', lambda e: self.event_generate("<<MoveWest>>"))
        self.bind('<d>', lambda e: self.event_generate("<<MoveEast>>"))
        self.bind('<i>', lambda e: self.event_generate("<<ToggleInventory>>"))
        self.bind('<Escape>', lambda e: self.show_pause_menu())
        self.bind('<Control-s>', lambda e: self.event_generate("<<SaveGame>>"))
        self.bind('<Control-l>', lambda e: self.event_generate("<<LoadGame>>"))

    def rebind_movement_keys(self):
        """
        Rebind the movement keys after closing inventory/merchant windows.
        """
        self.bind('<w>', lambda e: self.event_generate("<<MoveNorth>>"))
        self.bind('<s>', lambda e: self.event_generate("<<MoveSouth>>"))
        self.bind('<a>', lambda e: self.event_generate("<<MoveWest>>"))
        self.bind('<d>', lambda e: self.event_generate("<<MoveEast>>"))

    def show_pause_menu(self):
        """
        Show the pause menu.
        """
        pause_window = tk.Toplevel(self)
        pause_window.title("Pause Menu")
        pause_window.geometry("200x250")
        pause_window.transient(self)
        pause_window.grab_set()
        pause_window.focus_set()

        def on_closing():
            pause_window.grab_release()
            self.focus_force()
            pause_window.destroy()
        
        pause_window.protocol("WM_DELETE_WINDOW", on_closing)
        
        ttk.Button(pause_window, text="Resume", command=on_closing).pack(pady=5)
        ttk.Button(pause_window, text="Save Game", 
                  command=lambda: [self.event_generate("<<SaveGame>>"), on_closing()]).pack(pady=5)
        ttk.Button(pause_window, text="Load Game", 
                  command=lambda: [self.event_generate("<<LoadGame>>"), on_closing()]).pack(pady=5)
        ttk.Button(pause_window, text="Quit", 
                  command=lambda: [self.event_generate("<<QuitGame>>"), on_closing()]).pack(pady=5)

    def update_game_view(self, dungeon: Any, player: Any):
        """
        Update the game view.
        
        Args:
            dungeon: The current dungeon.
            player: The player character.
        """
        if self._current_frame:
            self._current_frame.update_game_view(dungeon, player)

    def update_stats_view(self, player: Any):
        """
        Update the stats view.
        
        Args:
            player: The player character.
        """
        self._player = player
        if isinstance(self._current_frame, GameFrame):
            self._current_frame.update_stats_view(player)

    def show_inventory_ui(self, player: Any):
        """
        Show the inventory user interface.
        
        Args:
            player: The player character.
        """
        if isinstance(self._current_frame, GameFrame):
            self._current_frame.show_inventory_ui(player)
            self.rebind_movement_keys()

    def show_merchant_ui(self, player: Any, merchant: Any):
        """
        Show the merchant user interface.
        
        Args:
            player: The player character.
            merchant: The merchant.
        """
        if isinstance(self._current_frame, GameFrame):
            self._current_frame.show_merchant_ui(player, merchant)
            self.rebind_movement_keys()

class GameFrame(ttk.Frame):
    """
    The main game frame class.
    """
    def __init__(self, master: tk.Tk):
        """
        Initialize the game frame.
        
        Args:
            master: The parent window.
        """
        super().__init__(master, style='Game.TFrame')
        self._setup_ui()
        self._bind_events()

    def _setup_ui(self):
        """
        Set up the user interface for the game frame.
        """
        self._game_view = ttk.Frame(self, style='Game.TFrame')
        self._game_view.pack(side='left', expand=True, fill='both')

        self._sidebar = ttk.Frame(self, style='Game.TFrame', width=250)
        self._sidebar.pack(side='right', fill='y')
        self._sidebar.pack_propagate(False)

        self._setup_equipment_display()
        self._setup_stats_view()
        self._setup_inventory_view()
        self._setup_action_buttons()

    def _setup_equipment_display(self):
        """
        Set up the equipment display in the sidebar.
        """
        self._equipment_frame = ttk.LabelFrame(self._sidebar, text="Equipment", style='Game.TFrame')
        self._equipment_frame.pack(fill='x', padx=5, pady=5)
        
        self._equipment_labels = {}
        for slot in ['Weapon', 'Armor', 'Shield']:
            self._equipment_labels[slot] = ttk.Label(
                self._equipment_frame,
                style='Equipment.TLabel',
                text=f"{slot}: None"
            )
            self._equipment_labels[slot].pack(fill='x', pady=1)

    def _setup_stats_view(self):
        """
        Set up the stats view in the sidebar.
        """
        self._stats_frame = ttk.LabelFrame(self._sidebar, text="Character Stats", style='Game.TFrame')
        self._stats_frame.pack(fill='x', padx=5, pady=5)
        
        self._stats_labels = {}
        for stat in ['Name', 'Title', 'Level', 'Health', 'Attack', 'Defense', 'XP', 'Money']:
            self._stats_labels[stat] = ttk.Label(self._stats_frame, style='Game.TLabel')
            self._stats_labels[stat].pack(anchor='w', padx=5)

    def _setup_inventory_view(self):
        """
        Set up the inventory view in the sidebar.
        """
        self._inventory_frame = ttk.LabelFrame(self._sidebar, text="Inventory", style='Game.TFrame')
        self._inventory_frame.pack(fill='x', padx=5, pady=5)
        
        self._inventory_list = tk.Listbox(
            self._inventory_frame,
            bg='black',
            fg='white',
            selectmode=tk.SINGLE,
            height=8
        )
        self._inventory_list.pack(fill='both', expand=True)

    def _setup_action_buttons(self):
        """
        Set up the action buttons in the sidebar.
        """
        button_frame = ttk.Frame(self._sidebar, style='Game.TFrame')
        button_frame.pack(fill='x', pady=5)
        
        ttk.Button(button_frame, text="Save (Ctrl+S)", 
                  command=lambda: self.event_generate("<<SaveGame>>")).pack(fill='x', padx=5, pady=2)
        ttk.Button(button_frame, text="Inventory (I)", 
                  command=lambda: self.event_generate("<<ToggleInventory>>")).pack(fill='x', padx=5, pady=2)

    def _bind_events(self):
        """
        Bind events for the game frame.
        """
        self._inventory_list.bind('<Double-Button-1>', self._handle_inventory_click)
        self._inventory_list.bind('<Button-3>', self._handle_inventory_click)

    def update_game_view(self, dungeon: Any, player: Any):
        """
        Update the game view.
        
        Args:
            dungeon: The current dungeon.
            player: The player character.
        """
        for widget in self._game_view.winfo_children():
            widget.destroy()

        canvas = tk.Canvas(
            self._game_view,
            bg='black',
            width=800,
            height=800
        )
        canvas.pack(expand=True)

        room_size = 80
        player_x, player_y = dungeon.player_pos
        offset_x = 400 - player_x * room_size
        offset_y = 400 - player_y * room_size

        for y in range(max(0, player_y-4), min(dungeon.size, player_y+5)):
            for x in range(max(0, player_x-4), min(dungeon.size, player_x+5)):
                if dungeon.rooms[y][x].is_visible:
                    self._draw_room(canvas, x, y, dungeon.rooms[y][x], room_size, offset_x, offset_y)

        self._draw_player(canvas, player_x, player_y, room_size, offset_x, offset_y)

    def _draw_room(self, canvas: tk.Canvas, x: int, y: int, room: Any, size: int, offset_x: int, offset_y: int):
        """
        Draw a single room on the game canvas.
        
        Args:
            canvas: The game canvas.
            x: The x-coordinate of the room.
            y: The y-coordinate of the room.
            room: The room object.
            size: The size of the room.
            offset_x: The x-offset for drawing.
            offset_y: The y-offset for drawing.
        """
        x1 = x * size + offset_x
        y1 = y * size + offset_y
        x2 = x1 + size
        y2 = y1 + size

        # Room background
        canvas.create_rectangle(x1, y1, x2, y2, fill='gray20', outline='white', width=2)

        # Doors
        wall_width = 8
        if not room.doors['north']:
            canvas.create_line(x1, y1, x2, y1, fill='white', width=wall_width)
        else:
            canvas.create_rectangle(x1 + size//3, y1-2, x2 - size//3, y1+2, fill='brown', outline='white')

        if not room.doors['south']:
            canvas.create_line(x1, y2, x2, y2, fill='white', width=wall_width)
        else:
            canvas.create_rectangle(x1 + size//3, y2-2, x2 - size//3, y2+2, fill='brown', outline='white')

        if not room.doors['east']:
            canvas.create_line(x2, y1, x2, y2, fill='white', width=wall_width)
        else:
            canvas.create_rectangle(x2-2, y1 + size//3, x2+2, y2 - size//3, fill='brown', outline='white')

        if not room.doors['west']:
            canvas.create_line(x1, y1, x1, y2, fill='white', width=wall_width)
        else:
            canvas.create_rectangle(x1-2, y1 + size//3, x1+2, y2 - size//3, fill='brown', outline='white')

        center_x = x1 + size//2
        center_y = y1 + size//2
        
        # Room contents
        if room.enemies:
            canvas.create_text(center_x, center_y-10, text='E', fill='red', font=('Arial', 16, 'bold'))
        if room.has_treasure and not room.treasure_looted:
            canvas.create_text(center_x, center_y, text='T', fill='yellow', font=('Arial', 16, 'bold'))
        if room.has_merchant and not room.merchant_visited:
            canvas.create_text(center_x, center_y, text='M', fill='green', font=('Arial', 16, 'bold'))
        if room.is_cleared:
            canvas.create_text(center_x+15, center_y-15, text='✓', fill='green', font=('Arial', 16, 'bold'))
        if room.is_end_room:
            canvas.create_text(center_x, center_y+15, text='N', fill='purple', font=('Arial', 16, 'bold'))

    def _draw_player(self, canvas: tk.Canvas, x: int, y: int, size: int, offset_x: int, offset_y: int):
        """
        Draw the player character on the game canvas.
        
        Args:
            canvas: The game canvas.
            x: The x-coordinate of the player.
            y: The y-coordinate of the player.
            size: The size of the room.
            offset_x: The x-offset for drawing.
            offset_y: The y-offset for drawing.
        """
        player_screen_x = x * size + offset_x + size//2
        player_screen_y = y * size + offset_y + size//2
        radius = 8
        canvas.create_oval(
            player_screen_x-radius, player_screen_y-radius,
            player_screen_x+radius, player_screen_y+radius,
            fill='green', outline='white', width=2
        )

    def update_stats_view(self, player: Any):
        """
        Update the stats view.
        
        Args:
            player: The player character.
        """
        self._stats_labels['Name'].config(text=f"Name: {player.name}")
        self._stats_labels['Title'].config(text=f"Title: {player.title}")
        self._stats_labels['Level'].config(text=f"Level: {player.tier}")
        self._stats_labels['Health'].config(text=f"Health: {player.current_health}/{player.max_health}")
        self._stats_labels['Attack'].config(text=f"Attack: {player.calculate_total_attack()}")
        self._stats_labels['Defense'].config(text=f"Defense: {player.calculate_total_defense()}")
        self._stats_labels['XP'].config(text=f"XP: {player.xp}")
        self._stats_labels['Money'].config(text=f"Money: {player.money} copper")

        self._update_equipment_display(player)
        self._update_inventory_list(player)

    def _update_equipment_display(self, player: Any):
        """
        Update the equipment display.
        
        Args:
            player: The player character.
        """
        equipment_info = player.get_equipment_display()
        
        self._equipment_labels['Weapon'].config(text=f"Weapon: {equipment_info['weapon']}")
        self._equipment_labels['Armor'].config(text=f"Armor: {equipment_info['armor']}")
        self._equipment_labels['Shield'].config(text=f"Shield: {equipment_info['shield']}")

    def _update_inventory_list(self, player: Any):
        """
        Update the inventory list.
        
        Args:
            player: The player character.
        """
        self._inventory_list.delete(0, tk.END)
        for item in player.inventory:
            display_text = item['name']
            if item['type'] == 'consumable':
                if 'effect' in item and item['effect'].startswith('heal_'):
                    heal_amount = int(item['effect'].split('_')[1])
                    display_text += f" (Heal: {heal_amount})"
            self._inventory_list.insert(tk.END, display_text)

    def show_inventory_ui(self, player: Any):
        """
        Show the inventory user interface.
        
        Args:
            player: The player character.
        """
        inventory_window = tk.Toplevel(self)
        inventory_window.title("Inventory")
        inventory_window.geometry("600x400")
        inventory_window.transient(self)
        inventory_window.grab_set()

        def on_closing():
            inventory_window.grab_release()
            self.master.focus_force()
            inventory_window.destroy()

        inventory_window.protocol("WM_DELETE_WINDOW", on_closing)

        # Equipment section
        equipment_frame = ttk.LabelFrame(inventory_window, text="Equipment", padding=10)
        equipment_frame.pack(fill='x', padx=5, pady=5)
        
        equipment_info = player.get_equipment_display()
        ttk.Label(equipment_frame, text=f"Weapon: {equipment_info['weapon']}").pack(anchor='w')
        ttk.Label(equipment_frame, text=f"Armor: {equipment_info['armor']}").pack(anchor='w')
        ttk.Label(equipment_frame, text=f"Shield: {equipment_info['shield']}").pack(anchor='w')

        # Inventory section
        inventory_frame = ttk.LabelFrame(inventory_window, text="Items", padding=10)
        inventory_frame.pack(fill='both', expand=True, padx=5, pady=5)

        # Create scrollable frame
        canvas = tk.Canvas(inventory_frame)
        scrollbar = ttk.Scrollbar(inventory_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Populate inventory items
        for item in player.inventory:
            item_frame = ttk.Frame(scrollable_frame)
            item_frame.pack(fill='x', padx=5, pady=2)
            
            # Item name and stats
            info_text = f"{item['name']}"
            if item['type'] == 'weapon':
                info_text += f" (DMG: {item['base_damage_min']}-{item['base_damage_max']})"
            elif item['type'] in ['armor', 'shield']:
                info_text += f" (DEF: {item['base_defense']})"
            elif item['type'] == 'consumable' and 'effect' in item:
                if item['effect'].startswith('heal_'):
                    heal_amount = int(item['effect'].split('_')[1])
                    info_text += f" (Heals {heal_amount} HP)"
                
            ttk.Label(item_frame, text=info_text).pack(side='left')
            
            # Action buttons based on item type
            if item['type'] in ['weapon', 'armor', 'shield']:
                ttk.Button(
                    item_frame,
                    text="Equip",
                    command=lambda i=item: self._equip_item(player, i, inventory_window)
                ).pack(side='right')
            elif item['type'] == 'consumable':
                ttk.Button(
                    item_frame,
                    text="Use",
                    command=lambda i=item: self._use_item(player, i, inventory_window)
                ).pack(side='right')

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Add close button
        ttk.Button(inventory_window, text="Close", command=on_closing).pack(pady=10)

    def show_merchant_ui(self, player: Any, merchant: Any):
        """
        Show the merchant user interface.
        
        Args:
            player: The player character.
            merchant: The merchant.
        """
        merchant_window = tk.Toplevel(self)
        merchant_window.title("Merchant")
        merchant_window.geometry("800x600")
        merchant_window.transient(self)
        merchant_window.grab_set()

        def on_closing():
            merchant_window.grab_release()
            self.master.focus_force()
            # Get reference to the current room and mark it as visited
            current_dungeon = self.master.current_frame.master.current_dungeon
            if current_dungeon:
                current_room = current_dungeon.get_current_room()
                if current_room:
                    current_room.merchant_visited = True
            merchant_window.destroy()

        merchant_window.protocol("WM_DELETE_WINDOW", on_closing)

        # Main container with two sides
        container = ttk.Frame(merchant_window)
        container.pack(fill='both', expand=True, padx=10, pady=10)

        # Merchant inventory side
        merchant_frame = ttk.LabelFrame(container, text="Merchant's Goods", padding=10)
        merchant_frame.pack(side='left', fill='both', expand=True)

        # Create notebook for categorized items
        item_notebook = ttk.Notebook(merchant_frame)
        item_notebook.pack(fill='both', expand=True)

        # Create pages for each item type
        item_types = merchant.get_available_types()
        type_frames = {}

        for item_type in item_types:
            frame = ttk.Frame(item_notebook)
            item_notebook.add(frame, text=item_type.capitalize())
            type_frames[item_type] = frame

            # Add scrollbar to each type frame
            canvas = tk.Canvas(frame)
            scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
            scrollable_frame = ttk.Frame(canvas)

            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )

            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)

            # Add items of this type
            items = merchant.get_inventory_by_type(item_type)
            for item in items:
                item_frame = ttk.Frame(scrollable_frame)
                item_frame.pack(fill='x', pady=2)
                
                # Item name and stats
                info_text = f"{item['name']}"
                if 'base_damage_min' in item:
                    info_text += f" (DMG: {item['base_damage_min']}-{item['base_damage_max']})"
                elif 'base_defense' in item:
                    info_text += f" (DEF: {item['base_defense']})"
                elif item['type'] == 'consumable' and 'effect' in item:
                    if item['effect'].startswith('heal_'):
                        heal_amount = int(item['effect'].split('_')[1])
                        info_text += f" (Heals {heal_amount} HP)"
                
                ttk.Label(item_frame, text=info_text).pack(side='left')
                ttk.Label(item_frame, text=f"{item['price_copper']} copper").pack(side='left', padx=10)
                
                buy_button = ttk.Button(
                    item_frame,
                    text="Buy",
                    command=lambda i=item: self._handle_buy(player, merchant, i, merchant_window)
                )
                buy_button.pack(side='right')
                
                # Disable buy button if player can't afford it
                if player.money < item['price_copper']:
                    buy_button.config(state='disabled')

            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")

        # Player inventory side
        player_frame = ttk.LabelFrame(container, text="Your Inventory", padding=10)
        player_frame.pack(side='right', fill='both', expand=True)

        # Player money display
        money_frame = ttk.Frame(player_frame)
        money_frame.pack(fill='x', pady=5)
        ttk.Label(money_frame, text="Your Money:", font=('Arial', 10, 'bold')).pack(side='left')
        ttk.Label(money_frame, text=f"{player.money} copper").pack(side='left', padx=5)

        # Scrollable player inventory
        canvas = tk.Canvas(player_frame)
        scrollbar = ttk.Scrollbar(player_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Player inventory list with sell buttons
        for item in player.inventory:
            item_frame = ttk.Frame(scrollable_frame)
            item_frame.pack(fill='x', pady=2)
            
            sell_value = merchant.get_item_value(item)
            ttk.Label(item_frame, text=f"{item['name']} (Sell: {sell_value} copper)").pack(side='left')
            
            ttk.Button(
                item_frame,
                text="Sell",
                command=lambda i=item: self._handle_sell(player, merchant, i, merchant_window)
            ).pack(side='right')

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Add close button
        ttk.Button(merchant_window, text="Close", command=on_closing).pack(pady=10)

    def _handle_inventory_click(self, event):
        """
        Handle inventory click event.
        
        Args:
            event: The click event.
        """
        selection = self._inventory_list.curselection()
        if not selection:
            return
            
        index = selection[0]
        item_name = self._inventory_list.get(index)
        
        popup = tk.Menu(self, tearoff=0)
        
        selected_item = None
        player = self.master._player
        for item in player.inventory:
            if item['name'] == item_name.split(' (')[0]:  # Remove the (Heal: X) part if present
                selected_item = item
                break
                
        if selected_item:
            if selected_item['type'] == 'consumable':
                popup.add_command(
                    label="Use",
                    command=lambda: self._use_item(player, selected_item, None)
                )
            elif selected_item['type'] in ['weapon', 'armor', 'shield']:
                popup.add_command(
                    label="Equip",
                    command=lambda: self._equip_item(player, selected_item, None)
                )
            
            popup.tk_popup(event.x_root, event.y_root)
            popup.grab_release()

    def _equip_item(self, player: Any, item: Dict, window: Optional[tk.Toplevel]):
        """
        Handle equipping items.
        
        Args:
            player: The player character.
            item: The item to equip.
            window: The inventory window.
        """
        if player.equip_item(item):
            self.update_stats_view(player)
            if window:
                window.grab_release()
                self.master.focus_force()
                window.destroy()
                self.show_inventory_ui(player)

    def _use_item(self, player: Any, item: Dict, window: Optional[tk.Toplevel]):
        """
        Handle using items.
        
        Args: 
            player: The player character.
            item: The item to use.
            window: The inventory window.
        """
        if item['type'] == 'consumable' and player.use_healing_potion(item):
            self.update_stats_view(player)
            if window:
                window.grab_release()
                self.master.focus_force()
                window.destroy()
                self.show_inventory_ui(player)

    def _handle_buy(self, player: Any, merchant: Any, item: Dict, window: tk.Toplevel):
        """
        Handle buying items from the merchant.

        Args:
            player: The player character.
            merchant: The merchant.
            item: The item to buy.
            window: The merchant window.
        """
        if player.money < item['price_copper']:
            messagebox.showwarning("Cannot Buy", "You don't have enough money!")
            return
            
        if merchant.buy_item(player, item['name']):
            self.update_stats_view(player)
            window.grab_release()
            self.master.focus_force()
            window.destroy()
            self.show_merchant_ui(player, merchant)
            messagebox.showinfo("Purchase Successful", f"You bought {item['name']}!")
        else:
            messagebox.showerror("Error", "Failed to complete purchase!")

    def _handle_sell(self, player: Any, merchant: Any, item: Dict, window: tk.Toplevel):
        """
        Handle selling items to the merchant.
        
        Args:
            player: The player character.
            merchant: The merchant.
            item: The item to sell.
            window: The merchant window.
        """
        sell_confirmation = messagebox.askyesno(
            "Confirm Sale",
            f"Are you sure you want to sell {item['name']} for {merchant.get_item_value(item)} copper?"
        )
        if not sell_confirmation:
            return
            
        if merchant.sell_item(player, item):
            self.update_stats_view(player)
            window.grab_release()
            self.master.focus_force()
            window.destroy()
            self.show_merchant_ui(player, merchant)
            messagebox.showinfo("Sale Successful", f"You sold {item['name']}!")
        else:
            messagebox.showerror("Error", "Failed to complete sale!")
