import tkinter as tk
from tkinter import messagebox, simpledialog
import logging
import json
import os
from datetime import datetime
import random

from config import WINDOW_WIDTH, WINDOW_HEIGHT, SAVE_DIR
from database import Database
from models.character import Character
from models.enemy import Enemy
from models.dungeon import Dungeon
from models.combat import CombatSystem
from models.merchant import Merchant
from gui.main_window import GameWindow, GameFrame
from gui.combat_window import CombatWindow

class Game:
    """
    The main game class.
    """
    def __init__(self):
        self._db = Database()
        self._window: Optional[GameWindow] = None
        self._player: Optional[Character] = None
        self._current_dungeon: Optional[Dungeon] = None
        self._merchant: Optional[Merchant] = None
        self._game_state = 'menu'  # menu, playing, combat, inventory, shopping
        self._combat_system = CombatSystem()

    def start(self):
        """
        Start the game.
        """
        self._window = GameWindow()
        self._setup_menu()
        self._bind_events()
        self._window.mainloop()

    def _setup_menu(self):
        """
        Set up the main menu.
        """
        menu_frame = ttk.Frame(self._window)
        menu_frame.pack(expand=True)
        
        title_label = ttk.Label(menu_frame, text="Dungeon RPG", font=('Arial', 24, 'bold'))
        title_label.pack(pady=20)
        
        ttk.Button(menu_frame, text="New Game", command=self._new_game).pack(pady=5)
        ttk.Button(menu_frame, text="Load Game", command=self._load_game).pack(pady=5)
        ttk.Button(menu_frame, text="Quit", command=self._window.quit).pack(pady=5)

    def _bind_events(self):
        """
        Bind game events.
        """
        self._window.bind_all('<Control-s>', lambda e: self._save_game())
        self._window.bind('<<SaveGame>>', lambda e: self._save_game())
        self._window.bind('<<LoadGame>>', lambda e: self._load_game())
        self._window.bind('<<QuitGame>>', lambda e: self._quit_game())
        self._window.bind('<<MoveNorth>>', lambda e: self._handle_movement('north'))
        self._window.bind('<<MoveSouth>>', lambda e: self._handle_movement('south'))
        self._window.bind('<<MoveEast>>', lambda e: self._handle_movement('east'))
        self._window.bind('<<MoveWest>>', lambda e: self._handle_movement('west'))
        self._window.bind('<<ToggleInventory>>', lambda e: self._handle_inventory())
        self._window.bind('<<OpenShop>>', lambda e: self._handle_shop())

    def _start_game(self):
        """
        Start a new game or load a saved game.
        """
        self._game_state = 'playing'
        if not self._merchant:
            self._merchant = Merchant()
        if self._window:
            self._window.clear_menu()
            self._window.setup_game_ui()
            self._window.bind_keys()
            self._update_display()

    def _new_game(self):
        """
        Start a new game.
        """
        dialog = tk.Toplevel(self._window)
        dialog.title("Create Character")
        dialog.geometry("300x200")
        dialog.transient(self._window)
        dialog.grab_set()
        
        ttk.Label(dialog, text="Character Name:").pack(pady=5)
        name_entry = ttk.Entry(dialog)
        name_entry.pack(pady=5)
        
        ttk.Label(dialog, text="Age:").pack(pady=5)
        age_entry = ttk.Entry(dialog)
        age_entry.pack(pady=5)
        
        def create_character():
            name = name_entry.get()
            try:
                age = int(age_entry.get())
                if 1 <= age <= 100:
                    dialog.destroy()
                    self._player = Character(name=name, age=age)
                    self._current_dungeon = Dungeon(tier=1)
                    self._start_game()
                else:
                    messagebox.showerror("Error", "Age must be between 1 and 100")
            except ValueError:
                messagebox.showerror("Error", "Age must be a number")
                
        ttk.Button(dialog, text="Create", command=create_character).pack(pady=20)

    def _load_game(self):
        """
        Load a saved game.
        """
        try:
            if not os.path.exists(SAVE_DIR):
                messagebox.showinfo("Load Game", "No saves directory found.")
                return

            save_files = [f for f in os.listdir(SAVE_DIR) if f.endswith('.json')]
            if not save_files:
                messagebox.showinfo("Load Game", "No saved games found.")
                return

            dialog = tk.Toplevel(self._window)
            dialog.title("Load Game")
            dialog.geometry("400x300")
            dialog.transient(self._window)
            dialog.grab_set()

            ttk.Label(dialog, text="Select Save File:").pack(pady=5)

            frame = ttk.Frame(dialog)
            frame.pack(fill='both', expand=True, padx=5, pady=5)
            
            scrollbar = ttk.Scrollbar(frame)
            scrollbar.pack(side='right', fill='y')
            
            save_list = tk.Listbox(frame, yscrollcommand=scrollbar.set)
            save_list.pack(side='left', fill='both', expand=True)
            
            scrollbar.config(command=save_list.yview)

            for file in sorted(save_files, reverse=True):
                save_list.insert(tk.END, file)

            def load_selected():
                selection = save_list.curselection()
                if not selection:
                    messagebox.showwarning("Load Game", "Please select a save file.")
                    return
                    
                save_file = save_list.get(selection[0])
                try:
                    with open(os.path.join(SAVE_DIR, save_file), 'r', encoding='utf-8') as f:
                        save_data = json.load(f)

                    if not self._validate_save_data(save_data):
                        raise ValueError("Invalid save file format")

                    self._player = Character(**save_data['player'])
                    self._current_dungeon = Dungeon(**save_data['dungeon'])
                    dialog.destroy()
                    self._start_game()
                except Exception as e:
                    logging.error(f"Error loading game: {str(e)}")
                    messagebox.showerror("Error", f"Failed to load game: {str(e)}")

            button_frame = ttk.Frame(dialog)
            button_frame.pack(fill='x', padx=5, pady=5)
            
            ttk.Button(button_frame, text="Load", command=load_selected).pack(side='left', padx=5)
            ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side='right', padx=5)

        except Exception as e:
            logging.error(f"Error accessing save files: {str(e)}")
            messagebox.showerror("Error", f"Failed to access save files: {str(e)}")

    def _save_game(self):
        """
        Save the current game.
        """
        def convert_types(obj):
            """
            Convert object types for JSON serialization.
            
            Args:
                obj: The object to convert.
                
            Returns:
                The converted object.
            """
            if isinstance(obj, dict):
                return {str(key): convert_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_types(item) for item in obj]
            elif isinstance(obj, (int, float, bool, str)) or obj is None:
                return obj
            return str(obj)

        try:
            if not self._player or not self._current_dungeon:
                raise ValueError("No active game to save")

            save_data = {
                'player': {
                    'name': str(self._player.name),
                    'age': int(self._player.age),
                    'tier': int(self._player.tier),
                    'xp': int(self._player.xp),
                    'current_health': int(self._player.current_health),
                    'inventory': convert_types(self._player.inventory),
                    'equipped_weapon': convert_types(self._player.equipped_weapon),
                    'equipped_armor': convert_types(self._player.equipped_armor),
                    'equipped_shield': convert_types(self._player.equipped_shield),
                    'money': int(self._player.money)
                },
                'dungeon': convert_types(self._current_dungeon.to_dict())
            }

            # Use character name for consistent save file
            filename = f"{self._player.name.lower().replace(' ', '_')}_save.json"
            filepath = os.path.join(SAVE_DIR, filename)
            
            os.makedirs(SAVE_DIR, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2, ensure_ascii=False)

            logging.info(f"Game saved: {filename}")
            messagebox.showinfo("Save Game", f"Game saved successfully!\nFile: {filename}")

        except Exception as e:
            logging.error(f"Error saving game: {str(e)}")
            messagebox.showerror("Error", f"Failed to save game: {str(e)}")

    def _validate_save_data(self, save_data: Dict[str, Any]) -> bool:
        """
        Validate the save data format.
        
        Args:
            save_data: The save data to validate.
            
        Returns:
            True if the save data is valid, False otherwise.
        """
        required_keys = {'player', 'dungeon'}
        player_keys = {'name', 'age', 'tier', 'xp', 'current_health', 'inventory'}
        dungeon_keys = {'tier', 'size', 'player_pos', 'rooms'}
        
        if not all(key in save_data for key in required_keys):
            return False
        if not all(key in save_data['player'] for key in player_keys):
            return False
        if not all(key in save_data['dungeon'] for key in dungeon_keys):
            return False
        return True

    def _update_display(self):
        """
        Update the game display.
        """
        if not self._window or not self._player or not self._current_dungeon:
            return
        self._window.update_game_view(self._current_dungeon, self._player)
        self._window.update_stats_view(self._player)
        if isinstance(self._window.current_frame, GameFrame):
            self._window.current_frame.update_equipment_display(self._player)

    def _handle_movement(self, direction: str):
        """
        Handle player movement.
        
        Args:
            direction: The direction to move.
        """
        if self._game_state != 'playing' or not self._current_dungeon:
            return

        if self._current_dungeon.move_player(direction):
            current_room = self._current_dungeon.get_current_room()
            if current_room.enemies and not current_room.is_cleared:
                self._start_combat(current_room.enemies[0])
            elif current_room.has_treasure and not current_room.treasure_looted:
                self._handle_treasure(current_room)
            elif current_room.has_merchant and not current_room.merchant_visited:
                self._handle_shop()
            elif current_room.is_end_room:
                self._handle_dungeon_end()
            self._update_display()

    def _handle_treasure(self, room):
        """
        Handle treasure room interaction.
        
        Args:
            room: The room with treasure.
        """
        loot = self._current_dungeon.get_treasure_loot()
        message = "You found a treasure chest!\n\nContents:\n"
        for item_name in loot:
            if isinstance(item_name, tuple) and item_name[0] == 'copper':
                self._player.money += item_name[1]
                message += f"- {item_name[1]} copper\n"
            else:
                item = self._db.get_item(item_name)
                if item:
                    self._player.add_item(item)
                    message += f"- {item['name']}\n"
        room.treasure_looted = True
        messagebox.showinfo("Treasure!", message)

    def _handle_shop(self):
        """
        Handle merchant interaction.
        """
        if not self._merchant or not self._player:
            return
            
        self._game_state = 'shopping'
        # Pass the current_dungeon reference to the window
        self._window.current_dungeon = self._current_dungeon
        self._window.show_merchant_ui(self._player, self._merchant)

    def _handle_dungeon_end(self):
        """
        Handle reaching the end of the dungeon.
        """
        if not self._player or not self._current_dungeon:
            return
            
        messagebox.showinfo("Dungeon Complete!", "You have reached the end of the dungeon!")
        self._current_dungeon = Dungeon(tier=self._player.tier)
        self._update_display()

    def _start_combat(self, enemy: Enemy):
        """
        Start a combat encounter.
        
        Args:
            enemy: The enemy to fight.
        """
        if not self._window or not self._player:
            return
            
        self._game_state = 'combat'
        combat_window = CombatWindow(
            self._window,
            self._player,
            enemy,
            self._combat_system,
            self._handle_combat_end
        )

    def _handle_combat_end(self, outcome: str):
        """
        Handle the end of a combat encounter.
        
        Args:
            outcome: The outcome of the combat.
        """
        if not self._current_dungeon:
            return
            
        self._game_state = 'playing'
        current_room = self._current_dungeon.get_current_room()

        if outcome == 'victory':
            current_room.is_cleared = True
            current_room.enemies = []
        elif outcome == 'fled':
            self._current_dungeon.move_player_random_adjacent()

        self._update_display()

    def _handle_inventory(self):
        """
        Handle opening the inventory.
        """
        if self._game_state == 'combat' or not self._window or not self._player:
            return

        self._game_state = 'inventory'
        self._window.show_inventory_ui(self._player)

    def _quit_game(self):
        """
        Quit the game.
        """
        if messagebox.askyesno("Quit Game", "Do you want to save before quitting?"):
            self._save_game()
        if self._window:
            self._window.quit()

def main():
    """
    The main function to start the game.
    """
    os.makedirs(SAVE_DIR, exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    try:
        game = Game()
        game.start()
    except Exception as e:
        logging.critical(f"Critical error in main game loop: {str(e)}")
        messagebox.showerror("Critical Error", f"A critical error occurred: {str(e)}")

if __name__ == "__main__":
    main()