import tkinter as tk
from tkinter import messagebox, ttk, simpledialog
import logging
import json
import os
from datetime import datetime
from typing import Optional, Dict, Any

from config import WINDOW_WIDTH, WINDOW_HEIGHT, SAVE_DIR
from database import Database
from models.character import Character
from models.enemy import Enemy
from models.dungeon import Dungeon
from models.combat import D20CombatSystem
from models.merchant import Merchant
from gui.main_window import GameWindow, GameFrame
from gui.combat_window import CombatWindow

class Game:
    def __init__(self):
        self.db = Database()
        self.window: Optional[GameWindow] = None
        self.player: Optional[Character] = None
        self.current_dungeon: Optional[Dungeon] = None
        self.merchant: Optional[Merchant] = None
        self.game_state = 'menu'  # menu, playing, combat, inventory, shopping
        self.combat_system = D20CombatSystem()

    def start(self):
        self.window = GameWindow()
        self.setup_menu()
        self.bind_events()
        self.window.mainloop()

    def setup_menu(self):
        menu_frame = ttk.Frame(self.window)
        menu_frame.pack(expand=True)
        
        title_label = ttk.Label(menu_frame, text="Dungeon RPG", font=('Arial', 24, 'bold'))
        title_label.pack(pady=20)
        
        ttk.Button(menu_frame, text="New Game", command=self.new_game).pack(pady=5)
        ttk.Button(menu_frame, text="Load Game", command=self.load_game).pack(pady=5)
        ttk.Button(menu_frame, text="Quit", command=self.window.quit).pack(pady=5)

    def bind_events(self):
        self.window.bind_all('<Control-s>', lambda e: self.save_game())
        self.window.bind('<<SaveGame>>', lambda e: self.save_game())
        self.window.bind('<<LoadGame>>', lambda e: self.load_game())
        self.window.bind('<<QuitGame>>', lambda e: self.quit_game())
        self.window.bind('<<MoveNorth>>', lambda e: self.handle_movement('north'))
        self.window.bind('<<MoveSouth>>', lambda e: self.handle_movement('south'))
        self.window.bind('<<MoveEast>>', lambda e: self.handle_movement('east'))
        self.window.bind('<<MoveWest>>', lambda e: self.handle_movement('west'))
        self.window.bind('<<ToggleInventory>>', lambda e: self.handle_inventory())
        self.window.bind('<<OpenShop>>', lambda e: self.handle_shop())

    def start_game(self):
        self.game_state = 'playing'
        if not self.merchant:
            self.merchant = Merchant()
        if self.window:
            self.window.clear_menu()
            self.window.setup_game_ui()
            self.window.bind_keys()
            self.update_display()

    def new_game(self):
        dialog = tk.Toplevel(self.window)
        dialog.title("Create Character")
        dialog.geometry("300x200")
        dialog.transient(self.window)
        dialog.grab_set()
        
        ttk.Label(dialog, text="Character Name:").pack(pady=5)
        name_entry = ttk.Entry(dialog)
        name_entry.pack(pady=5)
        
        ttk.Label(dialog, text="Age:").pack(pady=5)
        age_entry = ttk.Entry(dialog)
        age_entry.pack(pady=5)
        
        def create_character():
            name = name_entry.get()
            try:
                age = int(age_entry.get())
                if 1 <= age <= 100:
                    dialog.destroy()
                    self.player = Character(name=name, age=age)
                    self.current_dungeon = Dungeon(tier=1)
                    self.start_game()
                else:
                    messagebox.showerror("Error", "Age must be between 1 and 100")
            except ValueError:
                messagebox.showerror("Error", "Age must be a number")
                
        ttk.Button(dialog, text="Create", command=create_character).pack(pady=20)

    def load_game(self):
        try:
            if not os.path.exists(SAVE_DIR):
                messagebox.showinfo("Load Game", "No saves directory found.")
                return

            save_files = [f for f in os.listdir(SAVE_DIR) if f.endswith('.json')]
            if not save_files:
                messagebox.showinfo("Load Game", "No saved games found.")
                return

            dialog = tk.Toplevel(self.window)
            dialog.title("Load Game")
            dialog.geometry("400x300")
            dialog.transient(self.window)
            dialog.grab_set()

            ttk.Label(dialog, text="Select Save File:").pack(pady=5)

            frame = ttk.Frame(dialog)
            frame.pack(fill='both', expand=True, padx=5, pady=5)
            
            scrollbar = ttk.Scrollbar(frame)
            scrollbar.pack(side='right', fill='y')
            
            save_list = tk.Listbox(frame, yscrollcommand=scrollbar.set)
            save_list.pack(side='left', fill='both', expand=True)
            
            scrollbar.config(command=save_list.yview)

            for file in sorted(save_files, reverse=True):
                save_list.insert(tk.END, file)

            def load_selected():
                selection = save_list.curselection()
                if not selection:
                    messagebox.showwarning("Load Game", "Please select a save file.")
                    return
                    
                save_file = save_list.get(selection[0])
                try:
                    with open(os.path.join(SAVE_DIR, save_file), 'r', encoding='utf-8') as f:
                        save_data = json.load(f)

                    if not self.validate_save_data(save_data):
                        raise ValueError("Invalid save file format")

                    self.player = Character(**save_data['player'])
                    self.current_dungeon = Dungeon(**save_data['dungeon'])
                    dialog.destroy()
                    self.start_game()
                except Exception as e:
                    logging.error(f"Error loading game: {str(e)}")
                    messagebox.showerror("Error", f"Failed to load game: {str(e)}")

            button_frame = ttk.Frame(dialog)
            button_frame.pack(fill='x', padx=5, pady=5)
            
            ttk.Button(button_frame, text="Load", command=load_selected).pack(side='left', padx=5)
            ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side='right', padx=5)

        except Exception as e:
            logging.error(f"Error accessing save files: {str(e)}")
            messagebox.showerror("Error", f"Failed to access save files: {str(e)}")

    def save_game(self):
        def convert_types(obj):
            if isinstance(obj, dict):
                return {str(key): convert_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_types(item) for item in obj]
            elif isinstance(obj, (int, float, bool, str)) or obj is None:
                return obj
            return str(obj)

        try:
            if not self.player or not self.current_dungeon:
                raise ValueError("No active game to save")

            save_data = {
                'player': {
                    'name': str(self.player.name),
                    'age': int(self.player.age),
                    'tier': int(self.player.tier),
                    'xp': int(self.player.xp),
                    'current_health': int(self.player.current_health),
                    'inventory': convert_types(self.player.inventory),
                    'equipped_weapon': convert_types(self.player.equipped_weapon),
                    'equipped_armor': convert_types(self.player.equipped_armor),
                    'equipped_shield': convert_types(self.player.equipped_shield),
                    'money': int(self.player.money)
                },
                'dungeon': convert_types(self.current_dungeon.to_dict())
            }

            # Use character name for consistent save file
            filename = f"{self.player.name.lower().replace(' ', '_')}_save.json"
            filepath = os.path.join(SAVE_DIR, filename)
            
            os.makedirs(SAVE_DIR, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2, ensure_ascii=False)

            logging.info(f"Game saved: {filename}")
            messagebox.showinfo("Save Game", f"Game saved successfully!\nFile: {filename}")

        except Exception as e:
            logging.error(f"Error saving game: {str(e)}")
            messagebox.showerror("Error", f"Failed to save game: {str(e)}")

    def validate_save_data(self, save_data: Dict[str, Any]) -> bool:
        required_keys = {'player', 'dungeon'}
        player_keys = {'name', 'age', 'tier', 'xp', 'current_health', 'inventory'}
        dungeon_keys = {'tier', 'size', 'player_pos', 'rooms'}
        
        if not all(key in save_data for key in required_keys):
            return False
        if not all(key in save_data['player'] for key in player_keys):
            return False
        if not all(key in save_data['dungeon'] for key in dungeon_keys):
            return False
        return True

    def update_display(self):
        if not self.window or not self.player or not self.current_dungeon:
            return
        self.window.update_game_view(self.current_dungeon, self.player)
        self.window.update_stats_view(self.player)
        if isinstance(self.window.current_frame, GameFrame):
            self.window.current_frame.update_equipment_display(self.player)

    def handle_movement(self, direction: str):
        if self.game_state != 'playing' or not self.current_dungeon:
            return

        if self.current_dungeon.move_player(direction):
            current_room = self.current_dungeon.get_current_room()
            if current_room.enemies and not current_room.is_cleared:
                self.start_combat(current_room.enemies[0])
            elif current_room.has_treasure and not current_room.treasure_looted:
                self.handle_treasure(current_room)
            elif current_room.has_merchant and not current_room.merchant_visited:
                self.handle_shop()
            self.update_display()

    def handle_treasure(self, room):
        loot = self.current_dungeon.get_treasure_loot()
        message = "You found a treasure chest!\n\nContents:\n"
        for item_name in loot:
            if isinstance(item_name, tuple) and item_name[0] == 'copper':
                self.player.money += item_name[1]
                message += f"- {item_name[1]} copper\n"
            else:
                item = self.db.get_item(item_name)
                if item:
                    self.player.add_item(item)
                    message += f"- {item['name']}\n"
        room.treasure_looted = True
        messagebox.showinfo("Treasure!", message)

    def handle_shop(self):
        if not self.merchant or not self.player:
            return
            
        self.game_state = 'shopping'
        # Pass the current_dungeon reference to the window
        self.window.current_dungeon = self.current_dungeon
        self.window.show_merchant_ui(self.player, self.merchant)

    def start_combat(self, enemy: Enemy):
        if not self.window or not self.player:
            return
            
        self.game_state = 'combat'
        combat_window = CombatWindow(
            self.window,
            self.player,
            enemy,
            self.combat_system,
            self.handle_combat_end
        )

    def handle_combat_end(self, outcome: str):
        if not self.current_dungeon:
            return
            
        self.game_state = 'playing'
        current_room = self.current_dungeon.get_current_room()

        if outcome == 'victory':
            current_room.is_cleared = True
            current_room.enemies = []
        elif outcome == 'fled':
            self.current_dungeon.move_player_random_adjacent()

        self.update_display()

    def handle_inventory(self):
        if self.game_state == 'combat' or not self.window or not self.player:
            return

        self.game_state = 'inventory'
        self.window.show_inventory_ui(self.player)

    def quit_game(self):
        if messagebox.askyesno("Quit Game", "Do you want to save before quitting?"):
            self.save_game()
        if self.window:
            self.window.quit()

def main():
    os.makedirs(SAVE_DIR, exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    try:
        game = Game()
        game.start()
    except Exception as e:
        logging.critical(f"Critical error in main game loop: {str(e)}")
        messagebox.showerror("Critical Error", f"A critical error occurred: {str(e)}")

if __name__ == "__main__":
    main()