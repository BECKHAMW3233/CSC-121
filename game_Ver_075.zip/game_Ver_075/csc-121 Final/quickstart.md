# Dungeon RPG Quick Start Guide

## Getting Started
1. Launch the game
2. Choose "New Game"
3. Create your character by entering:
   - Character Name
   - Age (1-100)

## Basic Controls
- **W** - Move North
- **S** - Move South
- **A** - Move West
- **D** - Move East
- **I** - Open Inventory
- **Esc** - Open Pause Menu
- **Ctrl+S** - Quick Save

## Understanding the Display
- **Green Circle**: Your character
- **Red 'E'**: Enemy
- **Yellow 'T'**: Treasure
- **Green 'M'**: Merchant
- **Green '✓'**: Cleared room
- **Brown lines**: Doors
- **Gray lines**: Walls

## Combat
- Combat starts automatically when entering a room with an enemy
- Combat is turn-based using D20 system:
  - Natural 20: Critical hit (double damage)
  - Natural 1: Always miss
  - Players get +2 to hit and 20% bonus damage
- Actions available:
  - Attack: Basic attack with equipped weapon
  - Use Item: Use potions or other consumables
  - Flee: Attempt to escape combat (requires successful roll)

## Inventory Management
- Start with 5 Lesser Health Potions
- Equipment slots:
  - Weapon
  - Armor
  - Shield
- To equip items:
  - Open inventory with 'I'
  - Click "Equip" on desired item
- To use potions:
  - Open inventory
  - Click "Use" on the potion

## Trading
- Find merchant rooms (marked with 'M')
- Can buy new equipment and items
- Can sell unwanted items for 50% of base value
- Prices vary by ±20%

## Treasure
- Look for treasure rooms (marked with 'T')
- Can contain:
  - Copper coins
  - Equipment
  - Rare items
  - Chance for higher tier loot

## Tips for Success
1. Always keep healing potions ready
2. Explore carefully - higher tier enemies are tougher
3. Visit merchants to upgrade equipment
4. Look for treasure rooms for better loot
5. Save frequently using Ctrl+S
6. Flee from battles if badly wounded
7. Keep track of cleared rooms (marked with ✓)

Good luck, adventurer! May your quest be successful and profitable!