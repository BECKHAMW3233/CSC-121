# models.py
from dataclasses import dataclass
from enum import Enum, auto
from typing import Dict

class PaymentMethod(Enum):
    CASH = auto()
    CREDIT = auto()

@dataclass
class MoneyState:
    total_in: int
    total_out: int
    total_in_today: int
    credit_sales_today: int

    def add_money(self, amount_cents: int) -> None:
        self.total_in += amount_cents

    def remove_money(self, amount_cents: int) -> None:
        self.total_in -= amount_cents
        self.total_out += amount_cents

    def add_sale(self, amount_cents: int, payment_method: PaymentMethod) -> None:
        self.total_in_today += amount_cents
        if payment_method == PaymentMethod.CREDIT:
            self.credit_sales_today += amount_cents

@dataclass
class InventoryItem:
    price: int  # in cents
    quantity: int