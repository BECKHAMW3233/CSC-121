"""Main Flask application for the vending machine system."""

from flask import Flask, render_template, request, redirect, url_for, flash, session
from models import PaymentMethod, MoneyState, InventoryItem
from payment_processor import PaymentProcessor
from utils import format_price, calculate_change_breakdown
from config import DEFAULT_INVENTORY, INITIAL_MONEY, ADMIN_PASSWORD, MAX_CASHBACK
from storage import load_database, save_database, save_money_state, load_money_state
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='vending_machine.log'
)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev_key_123'
app.config['DEBUG'] = True
app.config['TEMPLATES_AUTO_RELOAD'] = True

# Initialize application state
try:
    inventory = load_database()
    money_state = load_money_state()
except Exception as e:
    logging.error(f"Error loading state: {e}")
    inventory = DEFAULT_INVENTORY.copy()
    money_state = MoneyState(
        total_in=INITIAL_MONEY,
        total_out=0,
        total_in_today=0,
        credit_sales_today=0
    )

payment_processor = PaymentProcessor(money_state)

@app.before_request
def before_request():
    """Initialize session variables before each request."""
    if 'cart' not in session:
        session['cart'] = {}
    if 'admin_authenticated' not in session:
        session['admin_authenticated'] = False

@app.route('/')
def index():
    """Render the main vending machine interface."""
    return render_template('index.html', 
                         inventory=inventory,
                         format_price=format_price)

@app.route('/add_to_cart/<item>')
def add_to_cart(item):
    """Add an item to the shopping cart if available."""
    if item in inventory and inventory[item].quantity > 0:
        cart = session.get('cart', {})
        cart[item] = cart.get(item, 0) + 1
        session['cart'] = cart
        inventory[item].quantity -= 1
        flash(f'Added {item} to cart')
        save_database(inventory)
    else:
        flash(f'{item} is out of stock')
    return redirect(url_for('index'))

@app.route('/remove_from_cart/<item>')
def remove_from_cart(item):
    """Remove an item from the shopping cart."""
    cart = session.get('cart', {})
    if item in cart:
        cart[item] -= 1
        inventory[item].quantity += 1
        if cart[item] == 0:
            del cart[item]
        session['cart'] = cart
        save_database(inventory)
        flash(f'Removed {item} from cart')
    return redirect(url_for('cart'))

@app.route('/cart')
def view_cart():
    """Display the shopping cart and total."""
    cart = session.get('cart', {})
    total = sum(inventory[item].price * quantity 
                for item, quantity in cart.items())
    return render_template('cart.html',
                         cart=cart,
                         inventory=inventory,
                         total=total,
                         format_price=format_price)

@app.route('/checkout', methods=['POST'])
def checkout():
    """Process payment for items in cart."""
    cart = session.get('cart', {})
    if not cart:
        flash('Cart is empty')
        return redirect(url_for('cart'))

    payment_method = PaymentMethod.CREDIT if request.form.get('payment') == 'credit' else PaymentMethod.CASH
    total_cents = sum(inventory[item].price * quantity 
                     for item, quantity in cart.items())

    if payment_method == PaymentMethod.CASH:
        try:
            cash_amount = float(request.form.get('cash_amount', 0))
            payment_cents = int(cash_amount * 100)
            if payment_cents < total_cents:
                flash('Insufficient payment')
                return redirect(url_for('cart'))

            change = payment_cents - total_cents
            money_state.add_money(payment_cents)
            money_state.add_sale(total_cents, payment_method)
            
            if change > 0:
                money_state.remove_money(change)
                change_breakdown = calculate_change_breakdown(change)
                flash(f'Payment successful! Your change: {format_price(change)}')
                flash(f'Change breakdown: {change_breakdown}')
            else:
                flash('Payment successful!')
            
            session['cart'] = {}
            save_money_state(money_state)
            return redirect(url_for('index'))
            
        except ValueError:
            flash('Invalid payment amount')
            return redirect(url_for('cart'))
            
    else:  # Credit payment
        cashback = request.form.get('cashback_amount', '')
        if cashback:
            try:
                cashback_cents = int(float(cashback) * 100)
                if cashback_cents > MAX_CASHBACK:
                    flash(f'Maximum cashback is {format_price(MAX_CASHBACK)}')
                    return redirect(url_for('cart'))
                    
                if not money_state.total_in >= cashback_cents:
                    flash('Unable to provide cashback at this time')
                    return redirect(url_for('cart'))
                    
                money_state.remove_money(cashback_cents)
                flash(f'Payment successful! Cashback: {format_price(cashback_cents)}')
            except ValueError:
                flash('Invalid cashback amount')
                return redirect(url_for('cart'))
        
        money_state.add_sale(total_cents, payment_method)
        session['cart'] = {}
        save_money_state(money_state)
        flash('Payment successful!')
        return redirect(url_for('index'))

    return redirect(url_for('cart'))

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    """Handle admin login and display admin panel."""
    if request.method == 'POST':
        if request.form.get('password') == ADMIN_PASSWORD:
            session['admin_authenticated'] = True
            return render_template('admin_panel.html', 
                                inventory=inventory,
                                money_state=money_state,
                                format_price=format_price)
        flash('Invalid password')
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    """Log out of admin panel."""
    session['admin_authenticated'] = False
    return redirect(url_for('index'))

@app.route('/admin/add_item', methods=['POST'])
def admin_add_item():
    """Add a new item to the inventory."""
    if not session.get('admin_authenticated'):
        return redirect(url_for('admin'))
    try:
        item_name = request.form['item_name'].lower()
        price = int(float(request.form['price']) * 100)
        quantity = int(request.form['quantity'])
        
        if price <= 0 or quantity < 0:
            flash('Price must be positive and quantity non-negative')
            return redirect(url_for('admin'))
            
        if item_name in inventory:
            flash('Item already exists')
            return redirect(url_for('admin'))
            
        inventory[item_name] = InventoryItem(price=price, quantity=quantity)
        save_database(inventory)
        flash(f'Added new item: {item_name}')
        logging.info(f"Admin added new item: {item_name}")
        
    except ValueError:
        flash('Invalid price or quantity')
    return redirect(url_for('admin'))

@app.route('/admin/delete_item/<item>')
def admin_delete_item(item):
    """Delete an item from the inventory."""
    if not session.get('admin_authenticated'):
        return redirect(url_for('admin'))
    if item in inventory:
        del inventory[item]
        save_database(inventory)
        flash(f'Deleted item: {item}')
        logging.info(f"Admin deleted item: {item}")
    return redirect(url_for('admin'))

@app.route('/admin/add_money', methods=['POST'])
def admin_add_money():
    """Add money to the machine."""
    if not session.get('admin_authenticated'):
        return redirect(url_for('admin'))
    try:
        amount = int(float(request.form['amount']) * 100)
        if amount > 0:
            money_state.add_money(amount)
            save_money_state(money_state)
            flash(f'Added {format_price(amount)}')
            logging.info(f"Admin added money: {format_price(amount)}")
        else:
            flash('Amount must be positive')
    except ValueError:
        flash('Invalid amount')
    return redirect(url_for('admin'))

@app.route('/admin/remove_money', methods=['POST'])
def admin_remove_money():
    """Remove money from the machine."""
    if not session.get('admin_authenticated'):
        return redirect(url_for('admin'))
    try:
        amount = int(float(request.form['amount']) * 100)
        if amount > 0:
            if money_state.total_in >= amount:
                money_state.remove_money(amount)
                save_money_state(money_state)
                flash(f'Removed {format_price(amount)}')
                logging.info(f"Admin removed money: {format_price(amount)}")
            else:
                flash('Insufficient funds')
        else:
            flash('Amount must be positive')
    except ValueError:
        flash('Invalid amount')
    return redirect(url_for('admin'))

@app.route('/admin/update_inventory', methods=['POST'])
def admin_update_inventory():
    """Update item price and quantity."""
    if not session.get('admin_authenticated'):
        return redirect(url_for('admin'))
    try:
        item = request.form['item']
        quantity = int(request.form['quantity'])
        price = int(float(request.form['price']) * 100)
        
        if quantity >= 0 and price > 0:
            if item in inventory:
                inventory[item] = InventoryItem(price=price, quantity=quantity)
                save_database(inventory)
                flash(f'Updated {item}: Price={format_price(price)}, Quantity={quantity}')
                logging.info(f"Admin updated inventory: {item} - Price: {format_price(price)}, Quantity: {quantity}")
            else:
                flash('Invalid item')
        else:
            flash('Quantity must be non-negative and price must be positive')
    except ValueError:
        flash('Invalid quantity or price')
    return redirect(url_for('admin'))

@app.route('/admin/report')
def admin_report():
    """Generate and display sales report."""
    if not session.get('admin_authenticated'):
        return redirect(url_for('admin'))
    try:
        report_data = {
            'total_money': money_state.total_in - money_state.total_out,
            'today_sales': money_state.total_in_today,
            'credit_sales': money_state.credit_sales_today,
            'inventory_value': sum(item.price * item.quantity 
                                 for item in inventory.values()),
            'inventory_counts': inventory,
            'cash_in_machine': money_state.total_in
        }
        return render_template('admin_report.html',
                             report=report_data,
                             format_price=format_price)
    except Exception as e:
        logging.error(f"Error generating report: {e}")
        flash('Error generating report')
        return redirect(url_for('admin'))

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors."""
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors."""
    logging.error(f"Server error: {e}")
    return render_template('500.html'), 500

if __name__ == '__main__':
    print("Starting vending machine web server...")
    app.run(debug=True)