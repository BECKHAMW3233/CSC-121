# utils.py
from typing import Dict

def format_price(cents: int) -> str:
    return f"${cents/100:.2f}"

def calculate_change_breakdown(cents: int) -> Dict[str, int]:
    denominations = {
        "dollars": 100,
        "quarters": 25,
        "dimes": 10,
        "nickels": 5,
        "pennies": 1
    }
    
    breakdown = {}
    remaining_cents = cents
    
    for name, value in denominations.items():
        count, remaining_cents = divmod(remaining_cents, value)
        if count > 0:
            breakdown[name] = count
            
    return breakdown