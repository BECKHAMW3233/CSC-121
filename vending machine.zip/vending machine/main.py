# main.py
import logging
from vending_machine import VendingMachine

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='vending_machine.log'
)

if __name__ == "__main__":
    machine = VendingMachine()
    machine.run()