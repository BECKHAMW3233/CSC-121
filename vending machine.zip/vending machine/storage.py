import csv
from typing import Dict
from models import MoneyState, InventoryItem
from config import CSV_FILE, MONEY_STATE_FILE, DEFAULT_INVENTORY, INITIAL_MONEY

def save_database(inventory: Dict[str, InventoryItem]) -> None:
    with open(CSV_FILE, 'w', newline='') as f:
        writer = csv.writer(f)
        for item, data in inventory.items():
            writer.writerow([item, data.price, data.quantity])

def load_database() -> Dict[str, InventoryItem]:
    try:
        with open(CSV_FILE, 'r') as f:
            reader = csv.reader(f)
            return {row[0]: InventoryItem(price=int(row[1]), quantity=int(row[2])) 
                   for row in reader}
    except FileNotFoundError:
        save_database(DEFAULT_INVENTORY)
        return DEFAULT_INVENTORY.copy()

def save_money_state(state: MoneyState) -> None:
    with open(MONEY_STATE_FILE, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            state.total_in,
            state.total_out,
            state.total_in_today,
            state.credit_sales_today
        ])

def load_money_state() -> MoneyState:
    try:
        with open(MONEY_STATE_FILE, 'r') as f:
            reader = csv.reader(f)
            row = next(reader)
            return MoneyState(
                total_in=int(row[0]),
                total_out=int(row[1]),
                total_in_today=int(row[2]),
                credit_sales_today=int(row[3])
            )
    except (FileNotFoundError, StopIteration):
        state = MoneyState(
            total_in=INITIAL_MONEY,
            total_out=0,
            total_in_today=0,
            credit_sales_today=0
        )
        save_money_state(state)
        return state