# payment_processor.py
from typing import Dict, Optional
import logging
from models import PaymentMethod, MoneyState
from utils import format_price, calculate_change_breakdown
from config import MAX_CASHBACK

class PaymentProcessor:
    def __init__(self, money_state: MoneyState):
        self.money_state = money_state

    def can_make_change(self, amount_cents: int) -> bool:
        return self.money_state.total_in >= amount_cents

    def process_payment(self, total_cents: int, payment_method: PaymentMethod) -> Optional[Dict[str, int]]:
        if payment_method == PaymentMethod.CREDIT:
            result = self._process_credit_payment(total_cents)
            self.money_state.add_sale(total_cents, PaymentMethod.CREDIT)
            return result
        
        payment_cents = int(float(input(f"Enter payment amount for {format_price(total_cents)}: ")) * 100)
        change_needed = payment_cents - total_cents
        
        if change_needed > 0 and not self.can_make_change(change_needed):
            print("Sorry, machine cannot make change at this time. Please use exact change or credit card.")
            return None
            
        return self._process_cash_payment(total_cents, payment_cents)

    def _process_credit_payment(self, total_cents: int) -> Optional[Dict[str, int]]:
        print(f"Total to pay: {format_price(total_cents)}")
        
        while True:
            cashback_choice = input("Do you want cashback? (yes/no): ").lower()
            if cashback_choice not in ['yes', 'no']:
                continue
                
            if cashback_choice == 'no':
                logging.info(f"Credit card payment processed: {format_price(total_cents)}")
                return None
                
            try:
                cashback_cents = int(float(input("Enter cashback amount (max $100): ")) * 100)
                if 0 <= cashback_cents <= MAX_CASHBACK:
                    if self.can_make_change(cashback_cents):
                        self.money_state.remove_money(cashback_cents)
                        logging.info(f"Credit card payment processed: {format_price(total_cents)} with {format_price(cashback_cents)} cashback")
                        return calculate_change_breakdown(cashback_cents)
                    else:
                        print("Sorry, insufficient funds for cashback. Please choose a smaller amount or no cashback.")
                else:
                    print("Invalid cashback amount")
            except ValueError:
                print("Please enter a valid number")

    def _process_cash_payment(self, total_cents: int, payment_cents: int) -> Optional[Dict[str, int]]:
        try:
            if payment_cents >= total_cents:
                change_cents = payment_cents - total_cents
                self.money_state.add_money(payment_cents)
                self.money_state.remove_money(change_cents)
                self.money_state.add_sale(total_cents, PaymentMethod.CASH)
                logging.info(f"Cash payment processed: {format_price(total_cents)}")
                return calculate_change_breakdown(change_cents)
            else:
                print("Insufficient payment")
                return None
        except ValueError:
            print("Please enter a valid amount")
            return None