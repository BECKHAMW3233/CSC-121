# config.py
from decimal import Decimal
from models import InventoryItem

CSV_FILE = "vending_machine_database.csv"
MONEY_STATE_FILE = "money_state.csv"
TAX_RATE = Decimal('0.02')
MAX_CASHBACK = 10000  # $100 in cents
ADMIN_PASSWORD = "admin123"
INITIAL_MONEY = 75000

DEFAULT_INVENTORY = {
    "apples": InventoryItem(price=369, quantity=50),
    "berries": InventoryItem(price=400, quantity=40),
    "chocolate": InventoryItem(price=289, quantity=60),
    "turkey": InventoryItem(price=699, quantity=30),
    "cheese": InventoryItem(price=400, quantity=45),
    "pepsi": InventoryItem(price=189, quantity=70),
    "eggs": InventoryItem(price=350, quantity=50),
    "bread": InventoryItem(price=300, quantity=55)
}