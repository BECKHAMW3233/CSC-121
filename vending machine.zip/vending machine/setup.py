# setup.py
import subprocess
import sys

def install_requirements():
    try:
        import flask
        print("Flask is already installed")
    except ImportError:
        print("Installing Flask...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "flask"])
        print("Flask installed successfully")

if __name__ == "__main__":
    install_requirements()
    # Run the Flask app after installation
    from app import app
    app.run(debug=True)