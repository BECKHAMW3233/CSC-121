# app.py
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from models import PaymentMethod, MoneyState
from payment_processor import PaymentProcessor
from utils import format_price
from config import DEFAULT_INVENTORY, INITIAL_MONEY
import logging

app = Flask(__name__)
app.secret_key = 'your-secret-key'

# Initialize state
money_state = MoneyState(
    total_in=INITIAL_MONEY,
    total_out=0,
    total_in_today=0,
    credit_sales_today=0
)
payment_processor = PaymentProcessor(money_state)
inventory = DEFAULT_INVENTORY.copy()
cart = {}

@app.route('/')
def index():
    print("Index route accessed")  # Debug print
    return render_template('index.html', 
                         inventory=inventory,
                         format_price=format_price)

if __name__ == "__main__":
    print("Starting Flask server...")
    app.run(debug=True, host='0.0.0.0', port=5000)
    print("Server is running!")