import csv
from dataclasses import dataclass
from typing import Optional, Tuple, List
import logging
from pathlib import Path

@dataclass
class Patient:
    """Represents a patient's data including calculated BMI and classification."""
    id: str
    height: float
    weight: float
    bmi: float = 0.0
    bmi_category: str = ""

def setup_logging():
    """Configure logging to both file and console."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('bmi_calculator.log'),
            logging.StreamHandler()
        ]
    )

def classify_bmi(bmi: float) -> str:
    """
    Classify BMI according to WHO standards.
    
    Parameters:
    bmi (float): The calculated BMI value
    
    Returns:
    str: BMI classification category
    """
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 25:
        return "Normal weight"
    elif 25 <= bmi < 30:
        return "Overweight"
    else:
        return "Obese"

def calculate_bmi(weight: float, height: float) -> float:
    """
    Calculate the Body Mass Index (BMI) given weight and height.

    Parameters:
    weight (float): The weight of the patient in pounds
    height (float): The height of the patient in inches

    Returns:
    float: The calculated BMI value rounded to two decimal places
    
    Raises:
    ValueError: If height is zero or negative
    """
    if height <= 0:
        raise ValueError("Height must be greater than zero")
    if weight <= 0:
        raise ValueError("Weight must be greater than zero")
    
    return round(weight / (height ** 2) * 703, 2)

def validate_patient_data(patient_id: str, height: str, weight: str) -> Tuple[Optional[float], Optional[float], List[str]]:
    """
    Validate patient data and convert to appropriate types.
    
    Returns:
    Tuple containing validated height, weight, and list of error messages
    """
    errors = []
    validated_height = None
    validated_weight = None
    
    try:
        validated_height = float(height)
        if validated_height <= 0:
            errors.append(f"Invalid height value: {height}")
            validated_height = None
    except ValueError:
        errors.append(f"Non-numeric height value: {height}")
    
    try:
        validated_weight = float(weight)
        if validated_weight <= 0:
            errors.append(f"Invalid weight value: {weight}")
            validated_weight = None
    except ValueError:
        errors.append(f"Non-numeric weight value: {weight}")
    
    return validated_height, validated_weight, errors

def process_patient_data(input_file: Path) -> List[Patient]:
    """Process patient data and return list of Patient objects."""
    patients = []
    
    with open(input_file, 'r') as infile:
        reader = csv.reader(infile)
        next(reader)  # Skip header
        
        for row in reader:
            patient_id, height, weight = row
            validated_height, validated_weight, errors = validate_patient_data(patient_id, height, weight)
            
            if errors:
                for error in errors:
                    logging.error(f"Patient ID {patient_id}: {error}")
                continue
            
            try:
                bmi = calculate_bmi(validated_weight, validated_height)
                bmi_category = classify_bmi(bmi)
                patient = Patient(patient_id, validated_height, validated_weight, bmi, bmi_category)
                patients.append(patient)
                logging.info(f"Processed Patient ID {patient_id}: BMI = {bmi:.2f}, Category: {bmi_category}")
            except ValueError as e:
                logging.error(f"Patient ID {patient_id}: {str(e)}")
    
    return patients

def save_results(patients: List[Patient], bmi_text_file: Path, bmi_csv_file: Path):
    """Save results to both text and CSV files."""
    with open(bmi_text_file, 'w') as txt_file:
        txt_file.write("Patient ID, BMI, Category\n")
        for patient in patients:
            txt_file.write(f"{patient.id}, {patient.bmi:.2f}, {patient.bmi_category}\n")
    
    with open(bmi_csv_file, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(['Patient ID', 'Height', 'Weight', 'BMI', 'BMI Category'])
        for patient in patients:
            writer.writerow([
                patient.id,
                patient.height,
                patient.weight,
                f"{patient.bmi:.2f}",
                patient.bmi_category
            ])

def main():
    """
    Main function to orchestrate BMI calculations and data processing.
    """
    setup_logging()
    
    input_file = Path('patients.csv')
    bmi_text_file = Path('bmi.txt')
    bmi_csv_file = Path('patient_bmi.csv')
    
    if not input_file.exists():
        logging.error(f"Input file {input_file} not found")
        return
    
    try:
        patients = process_patient_data(input_file)
        save_results(patients, bmi_text_file, bmi_csv_file)
        logging.info(f"Processing complete. Processed {len(patients)} patients successfully.")
        logging.info(f"Results saved to {bmi_text_file} and {bmi_csv_file}")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {str(e)}")

if __name__ == "__main__":
    main()